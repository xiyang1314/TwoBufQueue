#!/usr/bin/env python3
"""Fixed-capacity, neighborhood-supported SPSC comparison; no isolated peaks."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import random
import statistics
import subprocess
import sys
import tarfile
import time
import tune_spsc as tune

KIB, MIB = 1024, 1024**2
MODES = {
    'session': dict(use_write_session=True, publish_count=2**32-1, is_scan_current=False),
    'publish_max': dict(use_write_session=False, publish_count=2**32-1, is_scan_current=False),
    'publish1': dict(use_write_session=False, publish_count=1, is_scan_current=True),
}
OBJECTIVES = tune.OBJECTIVES
# Declare thresholds before measuring. They are not adjusted to obtain winners.
BANDS = dict(throughput=0.10, p50=0.15, p99=0.25, p999=0.35)
MAX_CV = dict(throughput=0.20, p50=0.25, p99=0.40, p999=0.60)
AXES = {
    'writer_block': ('source_block_size', ('source_block_size', 'source_pool_min', 'source_pool_max', 'source_queue_capacity')),
    'reader_block': ('output_block_size', ('output_block_size', 'output_pool_min', 'output_pool_max', 'output_queue_capacity')),
    'frame': ('output_frame_capacity', ('output_frame_capacity',)),
    'reader_spin': ('reader_spin_count', ('reader_spin_count',)),
    'scan_interval': ('rescan_interval_ns', ('rescan_interval_ns', 'rescan_max_interval_ns')),
    'spsc_spin': ('spsc_idle_spins', ('spsc_idle_spins',)),
    'spsc_sleep': ('spsc_idle_sleep_ns', ('spsc_idle_sleep_ns',)),
}

def mode_of(c):
    return 'session' if c['use_write_session'] else 'publish1' if c['publish_count']==1 else 'publish_max'

def distinct(configs):
    return list({tune.candidate_id(c): c for c in configs}.values())

def with_blocks(c, writer, reader, budget):
    if reader<writer or budget%writer or budget%reader or budget//writer<2:
        raise ValueError('exact pools and at least two Writer blocks required')
    return dict(c,source_block_size=writer,source_pool_min=budget//writer,source_pool_max=budget//writer,
                source_queue_capacity=max(512,budget//writer),output_block_size=reader,
                output_pool_min=budget//reader,output_pool_max=budget//reader,
                output_queue_capacity=max(512,budget//reader),buffer_budget_bytes=2*budget)

def retained_bytes(c,r):
    n,cap=c['payload_bytes'],r['actual_spsc_capacity']
    if c['transport']=='two_buf_queue': return c['source_block_size']*c['source_pool_max']+c['output_block_size']*c['output_pool_max']
    if c['transport']=='readerwriterqueue': return (cap//511)*512*n
    if c['transport']=='rigtorp': return (cap+1+2*((64+n-1)//n))*n
    return cap*n

def group(cs,length,transport,mode=None):
    return [c for c in cs if c['parameters']['payload_bytes']==length and c['parameters']['transport']==transport
            and (mode is None or mode_of(c['parameters'])==mode)]

def stable(candidate,objective,rows):
    matched=[r['result'] for r in rows if r['candidate_id']==candidate['candidate_id'] and r['stage']==candidate['stage']]
    if len(matched)!=6: return False
    if any(r['failed_write_calls'] or (r.get('library_backpressure') or {}).get('writer_pressure_events',0) for r in matched):
        return False
    if objective!='throughput' and tune.latency_status(candidate['metrics'],objective)!='observed': return False
    rs=[r for r in matched if r['config']['mode']==('throughput' if objective=='throughput' else 'write_latency')]
    vals=[r['m_messages_per_second'] if objective=='throughput' else r['batch_average_write_ns'][objective] for r in rs]
    mean=statistics.fmean(vals)
    return mean>0 and statistics.pstdev(vals)/mean<=MAX_CV[objective]

def families(candidates,axis):
    key,removed=AXES[axis]
    grouped={}
    for c in candidates:
        p=c['parameters']
        family=json.dumps({k:v for k,v in p.items() if k not in set(removed)|{'mode','messages','random_seed','verify_payload'}},sort_keys=True)
        grouped.setdefault(family,[]).append(c)
    return [sorted(g,key=lambda c:c['parameters'][key]) for g in grouped.values()]

def plateau_options(candidates,objective,axis,rows):
    result=[]
    key,_=AXES[axis]
    for family in families(candidates,axis):
        for i in range(1,len(family)-1):
            window=family[i-1:i+2]
            points=[c['parameters'][key] for c in window]
            if axis in ('writer_block','reader_block') and (points[1]!=2*points[0] or points[2]!=2*points[1]):
                continue
            if not all(stable(c,objective,rows) for c in window): continue
            vals=[c['metrics'][objective] for c in window]
            if min(vals)<=0 or max(vals)/min(vals)>1+BANDS[objective]: continue
            score=min(vals) if objective=='throughput' else max(vals)
            result.append(dict(candidate=family[i],axis=axis,neighbors=[c['candidate_id'] for c in window],
                               points=points,values=vals,score=score,relative_spread=max(vals)/min(vals)-1))
    return result

def best_plateau(candidates,objective,axis,rows):
    options=plateau_options(candidates,objective,axis,rows)
    if not options: return None
    if objective=='throughput':
        return max(options,key=lambda o:(o['score'],o['candidate']['metrics'][objective],-o['relative_spread']))
    return min(options,key=lambda o:(o['score'],o['candidate']['metrics'][objective],o['relative_spread']))

class AuditedSearch(tune.ParameterSearch):
    def __init__(self,*a,budget,**k):
        super().__init__(*a,**k);self.budget=budget
    def run_one(self,config,stage,trial,identity):
        assert config['round_storage_bytes']==self.budget*4//5
        assert config['fixed_round_boundaries'] and config['prepared_input'] and config['variable_payload']
        assert config['callback_iterations']==0 and config['latency_batch_size']==1000
        if config['transport']=='two_buf_queue':
            for prefix in ('source','output'):
                assert config[prefix+'_pool_min']==config[prefix+'_pool_max']
                assert config[prefix+'_block_size']*config[prefix+'_pool_max']==self.budget
        row=super().run_one(config,stage,trial,identity)
        if row:
            r=row['result'];p=r['config']
            assert r['source_record_bytes']==p['payload_bytes']
            assert r['effective_warmup_messages']==50_000
            assert r['timed_callback_messages']==r['consumed']==p['messages']
            assert r['completed_rounds']==math.ceil(p['messages']/(p['round_storage_bytes']//p['payload_bytes']))
            assert retained_bytes(p,r)<=(2*self.budget if p['transport']=='two_buf_queue' else self.budget)
            if p['mode']=='write_latency':
                assert r['latency_samples']*1000+r['latency_tail_writes']==p['messages'] and not r['migrated_samples']
        return row

def initial_configs(base,lengths,budget):
    writer_grid=[1<<e for e in range(10,budget.bit_length()-1)]
    cs=[]
    for n in lengths:
        for mode,settings in MODES.items():
            for w in writer_grid:
                for r in (MIB,16*MIB,budget):
                    if w<=r: cs.append(with_blocks(dict(base,payload_bytes=n,**settings),w,r,budget))
    return distinct(cs)

def native_configs(base,lengths,reference,budget):
    cs=[]
    for n in lengths:
        for transport in ('readerwriterqueue','rigtorp','atomic_queue'):
            original=reference['caches']['256'][f'{transport}_{n}']
            policy={k:original[k] for k in ('spsc_capacity','spsc_buffer_bytes','rigtorp_write_prefetch','readerwriterqueue_copy_after_zero')}
            for spin in (0,1000,10000):
                for sleep in (0,1000,10000):
                    cs.append(dict(base,transport=transport,payload_bytes=n,**MODES['publish_max'],
                                   spsc_idle_spins=spin,spsc_idle_sleep_ns=sleep,**policy))
    return distinct(cs)

def refinements(candidates,lengths,budget,rows):
    cs=[]
    for n in lengths:
        for mode in MODES:
            g=group(candidates,n,'two_buf_queue',mode)
            parents=[]
            for o in OBJECTIVES:
                plateau=best_plateau(g,o,'writer_block',rows)
                if plateau: parents.append(plateau['candidate']['parameters'])
                else: parents.append(tune.select_best(g,o)['parameters'])
            for p in distinct(parents):
                w=p['source_block_size']
                # Independent Reader-block neighbors, then three contiguous Writer sizes
                # at each fixed setting. All pools remain exactly 256 MiB.
                for reader in (p['output_block_size']//2,p['output_block_size'],p['output_block_size']*2):
                    if w<=reader<=budget:
                        for writer in (w//2,w,w*2):
                            if writer>=KIB and writer<=reader and writer<=budget//2:
                                cs.append(with_blocks(p,writer,reader,budget))
                for key,values in (('output_frame_capacity',(1,64,1024)),
                                   ('reader_spin_count',(0,1000,10000)),
                                   ('rescan_interval_ns',(1_000_000,5_000_000,30_000_000))):
                    if key=='rescan_interval_ns' and mode!='publish1': continue
                    for v in values:
                        changes={key:v}
                        if key=='rescan_interval_ns':changes['rescan_max_interval_ns']=v
                        for writer in (w//2,w,w*2):
                            if KIB<=writer<=min(p['output_block_size'],budget//2):
                                cs.append(with_blocks(dict(p,**changes),writer,p['output_block_size'],budget))
    return distinct(cs)

def select_groups(candidates,rows,lengths):
    selections=[];missing=[]
    for n in lengths:
        for transport in ('two_buf_queue','readerwriterqueue','rigtorp','atomic_queue'):
            for mode in (MODES if transport=='two_buf_queue' else (None,)):
                g=group(candidates,n,transport,mode)
                for o in OBJECTIVES:
                    axis='writer_block' if transport=='two_buf_queue' else 'spsc_spin'
                    selected=best_plateau(g,o,axis,rows)
                    if selected:
                        selections.append(dict(selected,payload_bytes=n,transport=transport,writer_mode=mode,objective=o))
                    else:missing.append(dict(payload_bytes=n,transport=transport,writer_mode=mode,objective=o,axis=axis))
    return selections,missing

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('executable',type=Path);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--reference',type=Path,default=Path(__file__).with_name('profiles')/'spsc_release.json')
    p.add_argument('--messages',type=int,default=10_000_000)
    p.add_argument('--lengths',type=int,nargs='+',default=[8,16,32,64])
    args=p.parse_args();budget=256*MIB
    profile=dict(payload_bytes=args.lengths,callback_iterations=[0],transports=list(tune.TRANSPORTS),spaces={},
        base=dict(warmup_messages=50_000,latency_batch_size=1000,
                  round_storage_bytes=budget*4//5,fixed_round_boundaries=True,output_mode='spsc',
                  output_reader_mode='wait_signal',output_frame_capacity=1024,reader_spin_count=1000,
                  rescan_interval_ns=1_000_000,rescan_max_interval_ns=1_000_000,
                  producer_cpu=-1,consumer_cpu=-1,producer_qos='user_interactive' if sys.platform=='darwin' else 'unchanged',
                  measure_callback_time=True,prepared_input=True,variable_payload=True,prefault_producer_buffers=True,
                  prepared_input_limit_bytes=budget,timeout_seconds=180),
        search=dict(screen_messages=args.messages,final_messages=args.messages,screen_repetitions=3,
                    final_repetitions=3,validation_messages=args.messages,batch_reference=False))
    if args.messages<1000 or set(args.lengths)-{8,16,32,64}:p.error('unsupported workload')
    if sys.platform=='darwin' and 'AC Power' not in subprocess.check_output(['pmset','-g','batt'],text=True):
        raise RuntimeError('AC power required')
    search=AuditedSearch(args.executable,profile,args.output,budget=budget)
    profile_path=args.output/'profile.json';profile_path.write_text(json.dumps(profile,indent=2)+'\n')
    tune.write_environment(search,profile_path)
    base=with_blocks(search.base,64*KIB,MIB,budget)
    reference=json.loads(args.reference.read_text())
    (args.output/'selection_policy.json').write_text(json.dumps(dict(bands=BANDS,max_cv=MAX_CV,
        neighborhood='three contiguous points, select center; 2x Writer/Reader spacing',
        score='worst neighboring mean: throughput maximin, latency minimax',
        excludes='zero failed writes and zero Writer pressure in every measured run; no unresolved latency',
        repetitions=3,isolated_peaks=False),indent=2)+'\n')
    cs=[];seen=set();stages=[]
    def screen(configs,label):
        fresh=[c for c in distinct(configs) if tune.candidate_id(c) not in seen]
        seen.update(tune.candidate_id(c) for c in fresh)
        print(label,len(fresh),'new configurations',flush=True)
        (args.output/(label+'_configs.json')).write_text(json.dumps(fresh,indent=2)+'\n')
        measured=search.evaluate(fresh,'screen')
        if len(measured)!=len(fresh) or search.failures:raise RuntimeError('retain failed/partial measurements, do not rank them')
        cs.extend(measured);stages.append(dict(stage=label,candidates=len(fresh)))
        (args.output/'screened.json').write_text(json.dumps(cs,indent=2)+'\n')
    screen(initial_configs(base,args.lengths,budget),'writer_reader_grid')
    screen(native_configs(base,args.lengths,reference,budget),'native_grid')
    screen(refinements(cs,args.lengths,budget,search.rows),'neighborhood_refinement')
    selections,missing=select_groups(cs,search.rows,args.lengths)
    (args.output/'plateau_screen.json').write_text(json.dumps(dict(selections=selections,missing=missing),indent=2)+'\n')
    # Confirm each chosen point together with both supporting neighbors, rather
    # than confirming only the apparent fastest point of a screening result.
    ids={i for s in selections for i in s['neighbors']}
    finalists=[c['parameters'] for c in cs if c['candidate_id'] in ids]
    print('independent neighborhood confirmation',len(finalists),flush=True)
    final=search.evaluate(distinct(finalists),'final')
    if len(final)!=len(distinct(finalists)) or search.failures:raise RuntimeError('incomplete confirmation')
    confirmed,unresolved=select_groups(final,search.rows,args.lengths)
    (args.output/'all_candidates.json').write_text(json.dumps(cs+final,indent=2)+'\n')
    (args.output/'plateau_final.json').write_text(json.dumps(dict(selections=confirmed,missing=unresolved),indent=2)+'\n')
    audit=dict(budget_bytes_per_pool=budget,round_storage_bytes=budget*4//5,messages=args.messages,
               repetitions=3,lengths=args.lengths,stages=stages,screen_candidates=len(cs),final_candidates=len(final),
               validation_runs=sum(r['stage']=='validation' for r in search.rows),
               measurement_runs=sum(r['stage']!='validation' for r in search.rows),failed_runs=len(search.failures),
               missing_plateaus=unresolved,extra_readback=True,session_readback=False,
               spsc_reference='same freshly measured native candidates reused for all three mode reports',
               source_harness='unmodified PerformanceTest',no_outlier_discard=True,
               executable_sha256=hashlib.sha256(args.executable.read_bytes()).hexdigest())
    (args.output/'audit.json').write_text(json.dumps(audit,indent=2)+'\n')
    search.raw.close();search.errors.close()
    print('Saved',args.output,'missing confirmed plateaus',len(unresolved),flush=True)

if __name__=='__main__':main()
