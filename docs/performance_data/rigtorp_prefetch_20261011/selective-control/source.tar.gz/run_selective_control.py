from pathlib import Path
import json,subprocess,statistics,hashlib,datetime,random,tarfile
R=Path('/Users/lc/Documents/TwoBufQueue');W=Path(__file__).resolve().parent;ROOT=W/'selective-control';ROOT.mkdir(exist_ok=True)
assert not (ROOT/'raw.jsonl').exists()
B=W/'selective/benchmark';settings={c:json.loads((R/f'docs/performance_data/release_20261011_rerun/configs_{c}m.json').read_text()) for c in [8,256]}
rows=[];specs=[(cache,n,enabled) for cache in [8,256] for n in [8,16,32,64] for enabled in [False,True]]
meta={'timestamp':datetime.datetime.now().astimezone().isoformat(),'change':'Same executable and input/callback/buffer/timing settings. Only rigtorp_write_prefetch flag differs; dispatch selects template before measurement. One full member copy in both paths; no extra zeroing or changed upstream queue code.','binary_sha256':hashlib.sha256(B.read_bytes()).hexdigest(),'build':json.loads(subprocess.check_output([str(B),'--build-info'],text=True)),'formal_messages':10000000,'repetitions':5,'library_sha256':hashlib.sha256((W.parent/'performance-rerun-20261011/build/libTwoBufQueue.a').read_bytes()).hexdigest()}
(ROOT/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
with tarfile.open(ROOT/'source.tar.gz','w:gz') as t:
 for p in (W/'selective').rglob('*'):
  if p.is_file() and p.suffix in ['.hpp','.cpp','.json','.s']:t.add(p,arcname=str(p.relative_to(W)))
 t.add(W/'run_selective_control.py',arcname='run_selective_control.py')
def run(spec,mode,trial,stage):
 cache,n,on=spec;c=dict(settings[cache][f'rigtorp_{n}'],rigtorp_write_prefetch=on,mode=mode,messages=10000000,verify_payload=stage=='validation',random_seed=42+trial)
 cmd=[str(B)]
 for k,v in c.items():cmd+=['--'+k,str(v).lower() if isinstance(v,bool) else str(v)]
 p=subprocess.run(cmd,capture_output=True,text=True,timeout=180)
 if p.returncode:raise RuntimeError(p.stderr)
 d=json.loads(p.stdout);assert d['config']==c and d['consumed']==10000000 and d['failed_write_calls']==0
 row={'cache_mib':cache,'payload_bytes':n,'write_prefetch':on,'stage':stage,'trial':trial,'command':cmd,'result':d};rows.append(row)
 with (ROOT/'raw.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
 if len(rows)%20==0:print('completed',len(rows),'of 176',flush=True)
for s in specs:run(s,'throughput',0,'validation')
for trial in range(5):
 jobs=[(s,m) for s in specs for m in ['throughput','write_latency']];random.Random(821+trial).shuffle(jobs)
 for s,m in jobs:run(s,m,trial,'final')
groups=[]
for cache,n,on in specs:
 rr=[x for x in rows if (x['cache_mib'],x['payload_bytes'],x['write_prefetch'])==(cache,n,on) and x['stage']=='final']
 tt=[x['result']['m_messages_per_second'] for x in rr if x['result']['config']['mode']=='throughput'];ll=[x['result']['batch_average_write_ns']['p50'] for x in rr if x['result']['config']['mode']=='write_latency'];assert len(tt)==len(ll)==5
 g={'cache_mib':cache,'payload_bytes':n,'write_prefetch':on,'throughput_mps':statistics.mean(tt),'throughput_runs_mps':tt,'p50_ns':statistics.mean(ll),'p50_runs_ns':ll};groups.append(g)
 print(cache,n,on,round(g['throughput_mps'],2),round(g['p50_ns'],3),flush=True)
(ROOT/'summary.json').write_text(json.dumps({'metadata':meta,'formal_runs':160,'validation_runs':16,'groups':groups},indent=2)+'\n');print('SAVED',ROOT,flush=True)
