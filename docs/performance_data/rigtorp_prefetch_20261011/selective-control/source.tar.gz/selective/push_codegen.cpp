#include "tunable/adapters.hpp"
using namespace TwoBufQueue::performance;
extern "C" bool ordinary16(rigtorp::SPSCQueue<Payload<16>>& q,const Payload<16>& m) {return q.try_push(m);}
extern "C" bool hinted16(rigtorp::SPSCQueue<Payload<16>>& q,const Payload<16>& m) {return q.try_emplace(m,DestinationWritePrefetch{});}
