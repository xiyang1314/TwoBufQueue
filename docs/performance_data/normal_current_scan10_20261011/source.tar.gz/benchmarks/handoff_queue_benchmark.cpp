#include "TwoBufQueue/src/base_components/HandoffQueue/handoff_queue.hpp"
#include <algorithm>
#include <array>
#include <barrier>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <string>

using namespace TwoBufQueue;
using Clock = std::chrono::steady_clock;
using Ns = std::chrono::nanoseconds;
static std::uint64_t ns(Clock::duration value) {
    return static_cast<std::uint64_t>(std::chrono::duration_cast<Ns>(value).count());
}
struct Message {
    bool reset(std::uint64_t) noexcept { return true; }
    std::size_t index = 0;
    Clock::time_point submitted;
    bool measured = false;
    std::array<std::uint64_t, 8> payload{};
};
struct Samples {
    std::vector<std::uint64_t> acquire, acquire_wait, send;
    std::uint64_t queue_full = 0, pool_limit = 0;
};
static std::uint64_t percentile(std::vector<std::uint64_t> values, unsigned percent) {
    std::sort(values.begin(), values.end());
    return values[(values.size() * percent + 99) / 100 - 1];
}
static void report(const char* name, int repeat, std::size_t producers, std::size_t readers,
                   const std::string& metric, const std::vector<std::uint64_t>& values,
                   double rate, std::uint64_t full, std::uint64_t limit) {
    std::cout << name << ',' << repeat << ',' << producers << ',' << readers << ',' << metric
              << ',' << values.size() << ',' << percentile(values, 50) << ',' << percentile(values, 99)
              << ',' << std::fixed << std::setprecision(0) << rate << ',' << full << ',' << limit << '\n';
}
static void run(const char* name, HandoffMode mode, ReaderMode reader_mode,
                std::size_t producers, std::size_t readers, std::size_t count, int repeat,
                std::size_t capacity) {
    constexpr std::size_t warmup = 2000;
    const auto total = count * producers;
    std::vector<std::uint64_t> callback_latency(total);
    std::vector<unsigned char> seen(total);
    std::vector<Samples> samples(producers);
    for (auto& sample : samples) {
        sample.acquire.resize(count);
        sample.acquire_wait.resize(count);
        sample.send.resize(count);
    }
    WarmPool<Message> pool(capacity, capacity);
    HandoffOptions options;
    options.mode = mode;
    options.reader_mode = reader_mode;
    options.reader_count = readers;
    options.queue_capacity = capacity;
    // 每线程本地记录失败数；组件的可选统计关闭，避免把统计成本混入基线。
    HandoffQueue pipeline(pool, options, [&](Message& message) noexcept {
        const auto entered = Clock::now();
        if (message.measured) {
            const auto i = message.index;
            if (i >= total || message.payload[0] != i || seen[i] != 0) std::abort();
            seen[i] = 1;
            callback_latency[i] = ns(entered - message.submitted);
        }
        return true;
    });
    Clock::time_point begin;
    std::barrier start(static_cast<std::ptrdiff_t>(producers + 1), [&]() noexcept {
        while (!pool.all_released()) std::this_thread::yield();
        begin = Clock::now();
    });
    std::vector<std::thread> threads;
    for (std::size_t p = 0; p < producers; ++p) {
        threads.emplace_back([&, p] {
            const auto acquire = [&](bool measure) {
                auto result = pipeline.try_acquire();
                while (!result) {
                    if (measure) {
                        if (result.status == AcquireStatus::QueueFull) ++samples[p].queue_full;
                        else if (result.status == AcquireStatus::PoolLimit) ++samples[p].pool_limit;
                        else std::abort();
                    }
                    std::this_thread::yield();
                    result = pipeline.try_acquire();
                }
                return result;
            };
            for (std::size_t i = 0; i < warmup; ++i) {
                auto result = acquire(false);
                result.loan->measured = false;
                if (!pipeline.send(result.loan)) std::abort();
            }
            start.arrive_and_wait();
            for (std::size_t i = 0; i < count; ++i) {
                const auto request_start = Clock::now();
                auto attempt_start = request_start;
                auto result = pipeline.try_acquire();
                while (!result) {
                    if (result.status == AcquireStatus::QueueFull) ++samples[p].queue_full;
                    else if (result.status == AcquireStatus::PoolLimit) ++samples[p].pool_limit;
                    else std::abort();
                    std::this_thread::yield();
                    attempt_start = Clock::now();
                    result = pipeline.try_acquire();
                }
                const auto acquired = Clock::now();
                samples[p].acquire[i] = ns(acquired - attempt_start);
                samples[p].acquire_wait[i] = ns(acquired - request_start);
                result.loan->index = p * count + i;
                result.loan->payload[0] = p * count + i;
                result.loan->measured = true;
                const auto submitted = Clock::now();
                result.loan->submitted = submitted;
                if (!pipeline.send(result.loan)) std::abort();
                samples[p].send[i] = ns(Clock::now() - submitted);
            }
        });
    }
    // 屏障 completion 等待预热资源全部归还，再记录起点并释放生产者。
    start.arrive_and_wait();
    for (auto& thread : threads) thread.join();
    pipeline.close();
    while (!pipeline.is_drained()) {
        if (Clock::now() > begin + std::chrono::seconds(60)) std::abort();
        std::this_thread::yield();
    }
    const auto end = Clock::now();
    pipeline.stop();
    if (std::accumulate(seen.begin(), seen.end(), std::size_t{0}) != total) std::abort();
    std::vector<std::uint64_t> acquired, wait, sent;
    acquired.reserve(total); wait.reserve(total); sent.reserve(total);
    std::uint64_t full = 0, limit = 0;
    for (const auto& sample : samples) {
        acquired.insert(acquired.end(), sample.acquire.begin(), sample.acquire.end());
        wait.insert(wait.end(), sample.acquire_wait.begin(), sample.acquire_wait.end());
        sent.insert(sent.end(), sample.send.begin(), sample.send.end());
        full += sample.queue_full; limit += sample.pool_limit;
    }
    const auto rate = static_cast<double>(total) / std::chrono::duration<double>(end - begin).count();
    report(name, repeat, producers, readers, "acquire_success", acquired, rate, full, limit);
    report(name, repeat, producers, readers, "acquire_including_retries", wait, rate, full, limit);
    report(name, repeat, producers, readers, "send", sent, rate, full, limit);
    report(name, repeat, producers, readers, "submit_to_callback", callback_latency, rate, full, limit);
}

int main(int argc, char** argv) {
    const auto count = argc > 1 ? std::stoull(argv[1]) : 50000;
    const auto repeats = argc > 2 ? std::stoi(argv[2]) : 3;
    const auto capacity = argc > 3 ? std::stoull(argv[3]) : 256;
    const std::string filter = argc > 4 ? argv[4] : "all";
    if (count < 100 || repeats < 1 || !capacity) return 2;
    std::vector<std::uint64_t> overhead(10000);
    for (auto& value : overhead) { const auto a = Clock::now(); value = ns(Clock::now() - a); }
    std::cerr << "clock_pair_ns p50=" << percentile(overhead, 50)
              << " p99=" << percentile(overhead, 99) << '\n';
    std::cout << "mode,repeat,producers,readers,metric,samples,p50_ns,p99_ns,messages_per_sec,queue_full,pool_limit\n";
    bool ran = false;
    for (int repeat = 1; repeat <= repeats; ++repeat) {
        const auto test = [&](const char* name, HandoffMode mode, ReaderMode reader,
                              std::size_t producers, std::size_t readers) {
            if (filter == "all" || filter == name) {
                run(name, mode, reader, producers, readers, count, repeat, capacity);
                ran = true;
            }
        };
        test("sync", HandoffMode::Sync, ReaderMode::Polling, 1, 0);
        for (auto reader : {ReaderMode::Polling, ReaderMode::WaitSignal}) {
            const bool poll = reader == ReaderMode::Polling;
            test(poll ? "spsc_poll" : "spsc_wait", HandoffMode::SPSC, reader, 1, 1);
            test(poll ? "mpsc_poll" : "mpsc_wait", HandoffMode::MPSC, reader, 4, 1);
            test(poll ? "spmc_poll" : "spmc_wait", HandoffMode::SPMC, reader, 1, 4);
            test(poll ? "mpmc_poll" : "mpmc_wait", HandoffMode::MPMC, reader, 4, 4);
            test(poll ? "mpsc_2_poll" : "mpsc_2_wait", HandoffMode::MPSC, reader, 2, 1);
            test(poll ? "mpsc_3_poll" : "mpsc_3_wait", HandoffMode::MPSC, reader, 3, 1);
            test(poll ? "mpmc_2_poll" : "mpmc_2_wait", HandoffMode::MPMC, reader, 2, 2);
            test(poll ? "mpsc_8_poll" : "mpsc_8_wait", HandoffMode::MPSC, reader, 8, 1);
        }
    }
    return ran ? 0 : 2;
}
