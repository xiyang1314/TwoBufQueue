#!/usr/bin/env python3
"""在独立进程中轮换运行顺序，对比队列性能；只使用 Python 标准库。"""
import argparse
import csv
import datetime
import hashlib
import io
import json
import math
from pathlib import Path
import platform
import statistics
import subprocess
import sys

TRANSPORTS = ["brq_direct", "brq_buffered", "moodycamel", "boost", "mutex"]


def capture(command, cwd=None):
    try:
        return subprocess.check_output(command, cwd=cwd, text=True, errors="replace", stderr=subprocess.STDOUT).strip()
    except (OSError, subprocess.CalledProcessError) as error:
        return str(error)


def cases(profile):
    if profile == "smoke":
        grid = [(1, 32), (2, 256), (4, 1024), (8, 32)]
    elif profile == "similar":
        grid = [(p, b) for p in (1, 4) for b in (32, 256, 1024)]
    elif profile == "headline":
        grid = [(1, 32), (4, 32)]
    else:
        grid = [(p, b) for p in (1, 2, 4, 8) for b in (32, 256, 1024)]
    result = [dict(name=f"saturated-p{p}-b{b}-batch{batch}", workload="saturated", producers=p,
                   bytes=b, batch=batch, sample=0) for p, b in grid for batch in (1, 32)]
    for workload in ("paced", "burst", "slow"):
        for p in (1, 4):
            result.append(dict(name=f"{workload}-p{p}", workload=workload, producers=p, bytes=32,
                               batch=1 if workload == "paced" else 32, sample=1 if workload == "paced" else 64))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("executable", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--profile", choices=["smoke", "headline", "full", "similar"], default="full")
    parser.add_argument("--trials", type=int, default=5)
    parser.add_argument("--min-seconds", type=float, default=0.5)
    parser.add_argument("--note", default="")
    parser.add_argument("--transports", nargs="+", choices=TRANSPORTS + ["atomic_queue", "rigtorp", "mengrao"], default=TRANSPORTS)
    parser.add_argument("--max-messages", type=int, default=10000000)
    args = parser.parse_args()
    if not 1 <= args.trials <= 20 or not 0.05 <= args.min_seconds <= 5:
        parser.error("trials must be 1..20; min-seconds must be 0.05..5")
    if len(set(args.transports)) != len(args.transports) or not 200000 <= args.max_messages <= 99999968:
        parser.error("unique transports and max-messages 200000..99999968 required")
    transports = args.transports
    executable = args.executable.resolve(strict=True)
    args.output.mkdir(parents=True, exist_ok=False)
    root = Path(__file__).resolve().parents[1]
    manifest = {}
    paths = list((root / "src").rglob("*.hpp")) + list((root / "src").rglob("*.cpp"))
    paths += [root / "CMakeLists.txt", root / "examples/example_support.hpp"]
    paths += [root / "benchmarks" / name for name in ("comparison.cpp", "process_metrics.hpp", "third_party.cmake", "compare.py", "extended_adapters.hpp", "extra_dependencies.json")]
    for path in sorted(paths):
        manifest[path.relative_to(root).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    fingerprint = hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest()
    cache = next((p / "CMakeCache.txt" for p in executable.parents if (p / "CMakeCache.txt").exists()), None)
    cache_lines = cache.read_text(encoding="utf-8", errors="replace").splitlines() if cache else []
    # Preserve flags and toolchain identity without publishing unrelated local paths.
    build = [line for line in cache_lines if line.startswith(("CMAKE_BUILD_TYPE:", "CMAKE_CXX_FLAGS:", "CMAKE_CXX_FLAGS_RELEASE:", "BRQ_DISABLE_TSC:", "CMAKE_GENERATOR:"))]
    compilers = list(cache.parent.glob("CMakeFiles/*/CMakeCXXCompiler.cmake")) if cache else []
    for path in compilers:
        build += [line for line in path.read_text(encoding="utf-8").splitlines() if line.startswith(("set(CMAKE_CXX_COMPILER_ID ", "set(CMAKE_CXX_COMPILER_VERSION "))]
    meta = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), platform=platform.platform(),
                processor=platform.processor(), profile=args.profile, trials=args.trials, min_seconds=args.min_seconds,
                note=args.note, git_head=capture(["git", "rev-parse", "HEAD"], root),
                source_fingerprint=fingerprint, source_files=manifest, build=build,
                executable_sha256=hashlib.sha256(executable.read_bytes()).hexdigest(),
                dependencies={"boost": "1.85.0", "moodycamel": "v1.0.4"}, transports=transports, max_messages=args.max_messages, commands=[])
    meta["extended_dependencies"] = json.loads((root / "benchmarks/extra_dependencies.json").read_text(encoding="utf-8"))
    if platform.system() == "Windows":
        meta["cpu"] = capture(["powershell", "-NoProfile", "-Command", "Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors | ConvertTo-Json"])
        meta["memory"] = capture(["powershell", "-NoProfile", "-Command", "(Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory"])
        meta["power_policy"] = capture(["powercfg", "/getactivescheme"])
    else:
        meta["cpu"] = capture(["lscpu"])
        meta["memory"] = capture(["free", "-b"])
    rows = []
    commands = meta["commands"]

    def execute(case, transport, count, phase, trial):
        command = [str(executable), "--transport", transport, "--workload", case["workload"],
                   "--producers", str(case["producers"]), "--bytes", str(case["bytes"]),
                   "--batch", str(case["batch"]), "--sample-every", str(case["sample"]), "--messages", str(count)]
        # Persist the portable argument vector; the binary's identity is above.
        commands.append(dict(case=case["name"], phase=phase, trial=trial, argv=["brq_compare", *command[1:]]))
        output = subprocess.check_output(command, text=True, timeout=180)
        parsed = list(csv.DictReader(io.StringIO(output)))
        if len(parsed) != 1 or None in parsed[0]:
            raise RuntimeError("invalid benchmark CSV")
        row = dict(case=case["name"], trial=trial, **parsed[0])
        if row["transport"] != transport or row["boost_version"] != "1_85":
            raise RuntimeError("benchmark identity mismatch")
        return row

    try:
        for number, case in enumerate(cases(args.profile), 1):
            count = 3000
            if args.profile != "smoke":
                if case["workload"] == "saturated":
                    # Warmup in separate processes; select ONE count for every transport.
                    pilot = [execute(case, t, 100000, "calibration", -1) for t in transports]
                    fastest = min(float(r["seconds"]) for r in pilot)
                    count = min(args.max_messages, max(200000, math.ceil(100000 * args.min_seconds / fastest)))
                elif case["workload"] == "paced":
                    count = 10000
                else:
                    count = 100000
            count = math.ceil(count / case["batch"]) * case["batch"]
            print(f"[{number}] {case['name']}: {count} messages/producer, {args.trials} trials", flush=True)
            for trial in range(args.trials):
                order = transports[trial % len(transports):] + transports[:trial % len(transports)]
                checksums = set()
                for transport in order:
                    row = execute(case, transport, count, "measured", trial)
                    checksums.add(row["checksum"])
                    rows.append(row)
                    with (args.output / "raw.csv").open("w", newline="", encoding="utf-8") as out:
                        writer = csv.DictWriter(out, fieldnames=list(rows[0]))
                        writer.writeheader(); writer.writerows(rows)
                if len(checksums) != 1:
                    raise RuntimeError("transports produced different checksums")
        meta["complete"] = True
    finally:
        (args.output / "environment.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
    summarize(args.output, rows, meta)
    print("报告：", args.output.resolve() / "SUMMARY.md", flush=True)


def summarize(directory, rows, meta):
    groups = {}
    for row in rows:
        groups.setdefault((row["case"], row["transport"]), []).append(row)
    summary = ["# 第三方队列对比结果", "", f"平台：{meta['platform']}。重复次数：{meta['trials']}。",
               "", "所有方案处理完整记录；支持原地读取的 SPSC 队列在原处消费，其他队列取出值后消费。各方案按每个生产者设置相同的在途额度，但内部内存布局和等待策略不同。CPU 核数＝进程 CPU 秒数／墙钟秒数。RSS 为包含初始化的进程生命周期峰值；每轮正式测量都使用新进程。",
               "", "| 用例 | 方案 | 吞吐中位数 Mmsg/s（最小–最大） | CPU 核数 | 峰值 RSS MiB | 端到端 p99 µs | 提交调用 p99 µs |",
               "|---|---|---:|---:|---:|---:|---:|"]
    for (case, transport), group in groups.items():
        def med(field): return statistics.median(float(r[field]) for r in group)
        rate = [float(r["msg_per_s"]) / 1e6 for r in group]
        def latency(field): return "—" if med(field) < 0 else f"{med(field):.3f}"
        summary.append(f"| {case} | {transport} | {statistics.median(rate):.3f} ({min(rate):.3f}–{max(rate):.3f}) | {med('cpu_cores'):.2f} | {med('peak_rss_mib'):.2f} | {latency('p99_us')} | {latency('call_p99_us')} |")
    short = sum(float(row["seconds"]) < 0.25 for row in rows)
    summary += ["", f"不足 0.25 秒的测量：{short}/{len(rows)}。若要比较稳定的速度比，应增加消息数量后重测。",
                "", "p99 列是各轮 p99 的中位数，不是合并样本后的分位数。提交调用延时包含重试，统计单位为一次应用提交；当 batch=32 时，它是整批延时，不是单条延时。",
                "", "没有指定 CPU 亲和性，不提供硬实时保证，也不声称全面优于第三方队列。低频延时从实际首次提交尝试开始计时，而不是从计划到达时刻开始；未做遗漏协调校正。", "", meta["note"], "",
                "原始数据见 `raw.csv`，环境与实际命令见 `environment.json`，方法见中文文档。源码指纹：`" + meta["source_fingerprint"] + "`。"]
    (directory / "SUMMARY.md").write_text("\n".join(summary) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
