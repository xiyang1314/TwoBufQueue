#include "TwoBufQueue/src/base_components/HandoffQueue/handoff_queue.hpp"
#ifndef BRQ_BENCH_PIPELINE_ONLY
#include "TwoBufQueue/src/base_components/HandoffQueue/lock_free_index_queue.hpp"
#endif
#include <array>
#include <barrier>
#include <chrono>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

using namespace TwoBufQueue;
using Clock = std::chrono::steady_clock;
struct Message {
    bool reset(std::uint64_t) noexcept { return true; }
    std::array<std::uint64_t, 8> payload{};
    std::uint64_t processed = 0, sum = 0;
    bool measured = false;
};
struct Config { const char* name; HandoffMode mode; std::size_t producers, readers; ReaderMode reader_mode; };
static const Config configs[] = {
    {"sync", HandoffMode::Sync, 1, 0, ReaderMode::Polling},
    {"spsc_poll", HandoffMode::SPSC, 1, 1, ReaderMode::Polling},
    {"mpsc_2_poll", HandoffMode::MPSC, 2, 1, ReaderMode::Polling},
    {"mpsc_3_poll", HandoffMode::MPSC, 3, 1, ReaderMode::Polling},
    {"spmc_2_poll", HandoffMode::SPMC, 1, 2, ReaderMode::Polling},
    {"spmc_3_poll", HandoffMode::SPMC, 1, 3, ReaderMode::Polling},
    {"mpmc_2_poll", HandoffMode::MPMC, 2, 2, ReaderMode::Polling},
    {"mpmc_4_poll", HandoffMode::MPMC, 4, 4, ReaderMode::Polling},
    {"spsc_wait", HandoffMode::SPSC, 1, 1, ReaderMode::WaitSignal},
    {"mpsc_2_wait", HandoffMode::MPSC, 2, 1, ReaderMode::WaitSignal},
    {"mpsc_3_wait", HandoffMode::MPSC, 3, 1, ReaderMode::WaitSignal},
    {"spmc_2_wait", HandoffMode::SPMC, 1, 2, ReaderMode::WaitSignal},
    {"spmc_3_wait", HandoffMode::SPMC, 1, 3, ReaderMode::WaitSignal},
    {"mpmc_2_wait", HandoffMode::MPMC, 2, 2, ReaderMode::WaitSignal},
    {"mpmc_4_wait", HandoffMode::MPMC, 4, 4, ReaderMode::WaitSignal},
};
static void report(const char* scope, const Config& config, std::size_t capacity,
                   std::size_t total, int repeat, double seconds) {
    std::cout << scope << ',' << config.name << ',' << repeat << ',' << config.producers << ','
        << config.readers << ',' << capacity << ',' << total << ',' << std::fixed
        << std::setprecision(6) << seconds << ',' << std::setprecision(0) << total / seconds << '\n';
}
// 不在每条消息上读时钟或争用统计原子；仅计时整个预热后的处理区间。
static void pipeline_run(const Config& config, std::size_t capacity, std::size_t count, int repeat) {
    WarmPool<Message> pool(capacity, capacity);
    HandoffOptions options;
    options.mode = config.mode; options.reader_count = config.readers;
    options.reader_mode = config.reader_mode; options.queue_capacity = capacity;
    HandoffQueue pipeline(pool, options, [](Message& message) noexcept {
        if (message.measured) { ++message.processed; message.sum += message.payload[0]; }
        return true;
    });
    Clock::time_point begin;
    std::barrier start(static_cast<std::ptrdiff_t>(config.producers + 1), [&]() noexcept {
        while (!pool.all_released()) std::this_thread::yield();
        begin = Clock::now();
    });
    std::vector<std::thread> producers;
    for (std::size_t p = 0; p < config.producers; ++p) producers.emplace_back([&, p] {
        const auto send = [&](std::size_t id, bool measured) {
            auto result = pipeline.try_acquire();
            while (!result) {
                if (result.status != AcquireStatus::QueueFull && result.status != AcquireStatus::PoolLimit)
                    std::abort();
                std::this_thread::yield();
                result = pipeline.try_acquire();
            }
            result.loan->payload[0] = id;
            result.loan->measured = measured;
            if (!pipeline.send(result.loan)) std::abort();
        };
        for (std::size_t i = 0; i < 2000; ++i) send(0, false);
        start.arrive_and_wait();
        for (std::size_t i = 0; i < count; ++i) send(p * count + i, true);
    });
    start.arrive_and_wait();
    for (auto& producer : producers) producer.join();
    pipeline.close();
    while (!pipeline.is_drained()) {
        if (Clock::now() > begin + std::chrono::seconds(120)) std::abort();
        std::this_thread::yield();
    }
    const auto seconds = std::chrono::duration<double>(Clock::now() - begin).count();
    pipeline.stop();
    std::vector<Loan<Message>> loans;
    std::uint64_t processed = 0, sum = 0;
    while (auto loan = pool.get()) { processed += loan->processed; sum += loan->sum; loans.push_back(loan); }
    for (auto loan : loans) if (!pool.recycle(loan)) std::abort();
    const auto total = count * config.producers;
    if (processed != total || sum != total * (total - 1) / 2) std::abort();
    report("pipeline", config, capacity, total, repeat, seconds);
}

#ifndef BRQ_BENCH_PIPELINE_ONLY
static void index_run(const Config& config, std::size_t capacity, std::size_t count, int repeat) {
    LockFreeIndexQueue queue(capacity);
    const auto total = count * config.producers;
    if (total > std::numeric_limits<std::uint32_t>::max()) std::abort();
    // 先触碰预分配节点；测量不包含线程启动、动态分配或每条消息的读时钟。
    for (std::size_t i = 0; i < 2000; ++i) {
        std::uint32_t value;
        if (!queue.try_push(1) || !queue.try_pop(value) || value != 1) std::abort();
    }
    struct alignas(64) Result { std::uint64_t count = 0, sum = 0; };
    std::vector<Result> results(config.readers);
    std::atomic<std::size_t> producers_left{config.producers};
    Clock::time_point begin;
    std::barrier start(static_cast<std::ptrdiff_t>(config.producers + config.readers + 1),
                       [&]() noexcept { begin = Clock::now(); });
    std::vector<std::thread> threads;
    for (std::size_t p = 0; p < config.producers; ++p) threads.emplace_back([&, p] {
        start.arrive_and_wait();
        for (std::size_t i = 0; i < count; ++i)
            while (!queue.try_push(static_cast<std::uint32_t>(p * count + i))) std::this_thread::yield();
        producers_left.fetch_sub(1, std::memory_order_release);
    });
    for (std::size_t c = 0; c < config.readers; ++c) threads.emplace_back([&, c] {
        start.arrive_and_wait();
        auto& result = results[c];
        for (;;) {
            std::uint32_t value;
            if (queue.try_pop(value)) { ++result.count; result.sum += value; }
            else if (!producers_left.load(std::memory_order_acquire) && !queue.has_ready()) break;
            else std::this_thread::yield();
        }
    });
    start.arrive_and_wait();
    for (auto& thread : threads) thread.join();
    const auto seconds = std::chrono::duration<double>(Clock::now() - begin).count();
    std::uint64_t processed = 0, sum = 0;
    for (const auto& result : results) { processed += result.count; sum += result.sum; }
    if (processed != total || sum != total * (total - 1) / 2) std::abort();
    report("index_queue", config, capacity, total, repeat, seconds);
}
#endif

int main(int argc, char** argv) {
    const auto count = argc > 1 ? std::stoull(argv[1]) : 500000;
    const auto repeats = argc > 2 ? std::stoi(argv[2]) : 3;
    const auto capacity = argc > 3 ? std::stoull(argv[3]) : 256;
    const std::string filter = argc > 4 ? argv[4] : "all";
    const std::string scope = argc > 5 ? argv[5] : "all";
    if (count < 100 || repeats < 1 || !capacity) return 2;
    std::cout << "scope,mode,repeat,producers,readers,capacity,messages,seconds,messages_per_sec\n";
    bool ran = false;
    for (int repeat = 1; repeat <= repeats; ++repeat) for (const auto& config : configs) {
        if (filter != "all" && filter != config.name) continue;
        if (scope == "all" || scope == "pipeline") { pipeline_run(config, capacity, count, repeat); ran = true; }
#ifndef BRQ_BENCH_PIPELINE_ONLY
        if ((scope == "all" || scope == "index") && config.readers && config.reader_mode == ReaderMode::Polling) {
            index_run(config, capacity, count, repeat); ran = true;
        }
#endif
    }
    return ran ? 0 : 2;
}
