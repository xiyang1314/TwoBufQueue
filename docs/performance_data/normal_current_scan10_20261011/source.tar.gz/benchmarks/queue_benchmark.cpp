#include "../examples/example_support.hpp"
#include <algorithm>
#include <condition_variable>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <thread>

using namespace TwoBufQueue;
using Clock = std::chrono::steady_clock;
struct Options {
    std::size_t messages = 200000, producers = 1, bytes = 64, repeats = 5;
    std::size_t sample_every = 0, interval_us = 0, block_bytes = 65536, blocks = 8;
};
struct Header { std::uint64_t sequence; std::int64_t sent_ns; std::uint64_t producer; };
static std::int64_t now_ns() noexcept {
    return std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now().time_since_epoch()).count();
}

// All transports feed this same validator. No output or allocation in the hot path.
struct Receiver {
    const Options& options;
    std::vector<std::uint64_t> next;
    std::vector<std::int64_t> latency;
    std::uint64_t checksum = 0, received = 0;
    bool valid = true;
    explicit Receiver(const Options& o) : options(o), next(o.producers) {
        if (o.sample_every) latency.reserve(o.producers * ((o.messages - 1) / o.sample_every + 1));
    }
    void consume(const std::byte* data, std::size_t size) noexcept {
        if (size != options.bytes) { valid = false; return; }
        Header header{};
        std::memcpy(&header, data, sizeof(header));
        if (header.sent_ns) latency.push_back(now_ns() - header.sent_ns);
        if (header.producer >= next.size()) { valid = false; return; }
        valid &= header.sequence == next[header.producer]++;
        const auto expected = static_cast<std::byte>((header.producer + header.sequence) & 255);
        for (std::size_t i = sizeof(header); i < size; ++i) valid &= data[i] == expected;
        checksum += header.sequence + header.producer + std::to_integer<unsigned>(data[size - 1]);
        ++received;
    }
    template<class Batch> static bool callback(void* context, const Batch& batch) noexcept {
        auto& self = *static_cast<Receiver*>(context);
        self.valid &= example::messages(batch, [&](std::int32_t, const std::byte* p, std::size_t size) noexcept {
            self.consume(p, size);
            return true;
        });
        return true;
    }
    DataCallback handler() { return {[](void* p, DataBatch& b) noexcept { return callback(p, b); }, this}; }
    ReadCallback read_callback() { return {callback<ReadBatch>, this}; }
};

// Bounded MPSC baseline: preallocated ring, one mutex, batched dequeue outside lock.
// It is intentionally more competitive than a heap-allocating std::queue per record.
class MutexBatchQueue {
public:
    MutexBatchQueue(std::size_t capacity, std::size_t bytes)
        : capacity_(capacity), bytes_(bytes), data_(capacity * bytes) {}
    bool push(const std::byte* data) {
        std::unique_lock lock(mutex_);
        if (count_ == capacity_) return false;
        std::memcpy(data_.data() + write_ * bytes_, data, bytes_);
        write_ = (write_ + 1) % capacity_;
        ++count_;
        lock.unlock();
        available_.notify_one();
        return true;
    }
    std::size_t pop(std::byte* out, std::size_t maximum) {
        std::unique_lock lock(mutex_);
        available_.wait_for(lock, std::chrono::milliseconds{1}, [&] { return count_ != 0; });
        const auto n = std::min(count_, maximum);
        for (std::size_t i = 0; i < n; ++i) {
            std::memcpy(out + i * bytes_, data_.data() + read_ * bytes_, bytes_);
            read_ = (read_ + 1) % capacity_;
        }
        count_ -= n;
        return n;
    }
private:
    std::size_t capacity_, bytes_, read_ = 0, write_ = 0, count_ = 0;
    std::vector<std::byte> data_;
    std::mutex mutex_;
    std::condition_variable available_;
};

struct Result {
    double seconds = 0;
    std::uint64_t received = 0, retries = 0, checksum = 0;
    std::vector<std::int64_t> latency;
};

static Result run(const Options& o, const std::string& transport) {
    const bool baseline = transport == "mutex_batch";
    const bool buffered = transport == "brq_buffered";
    Receiver receiver(o);
    using RecordWriter = Writer<1, true>;
    std::vector<std::unique_ptr<WriterPool>> buffers;
    std::vector<std::unique_ptr<WriterQueue>> queues;
    std::vector<std::unique_ptr<RecordWriter>> writers;
    if (!baseline) for (std::size_t i = 0; i < o.producers; ++i) {
        buffers.push_back(std::make_unique<WriterPool>(o.blocks, o.blocks, SpscBlockFactory<SpscWriteBlock>{o.block_bytes}));
        queues.push_back(std::make_unique<WriterQueue>(*buffers.back(), 256, writer_queue_callbacks));
        writers.push_back(std::make_unique<RecordWriter>(queues.back().get(), static_cast<std::int32_t>(i)));
    }
    std::unique_ptr<MutexBatchQueue> queue;
    if (baseline) queue = std::make_unique<MutexBatchQueue>(o.producers * o.blocks * (o.block_bytes / (o.bytes + 2)), o.bytes);
    std::unique_ptr<BigMemoryStore> store;
    std::unique_ptr<SaveMemoryAdapter> saver;
    std::unique_ptr<ReadWorker> reader;
    std::unique_ptr<QueueReader> consumer;
    if (!baseline) {
        auto handler = receiver.read_callback();
        if (buffered) {
            BigMemoryStoreConfig config;
            config.block_size = config.max_batch_bytes = o.block_bytes;
            config.initial_block_count = config.max_block_count = o.blocks * o.producers;
            config.batch_queue_capacity = 64;
            store = std::make_unique<BigMemoryStore>(config);
            saver = std::make_unique<SaveMemoryAdapter>(*store);
            handler = saver->completed_callback();
        }
        reader = std::make_unique<ReadWorker>(ReadConfig{}, handler, handler);
        for (std::size_t i = 0; i < o.producers; ++i)
            example::require(reader->add_writer(writers[i].get()), "registration failed");
        if (buffered) {
            consumer = std::make_unique<QueueReader>(*store, receiver.handler());
            store->set_batch_available_callback([](void* p) noexcept { static_cast<QueueReader*>(p)->notify(); }, consumer.get());
            store->set_space_available_callback([](void* p) noexcept { static_cast<ReadWorker*>(p)->notify_memory_available(); }, reader.get());
            example::require(consumer->start(), "consumer start failed");
        }
        example::require(reader->start(), "reader start failed");
    }
    std::atomic<bool> go{false}, done{false};
    std::atomic<std::size_t> ready{0};
    std::vector<std::uint64_t> retries(o.producers);
    std::vector<std::vector<std::byte>> payloads(o.producers, std::vector<std::byte>(o.bytes));
    std::vector<std::byte> dequeue_buffer(baseline ? 256 * o.bytes : 0);
    Clock::time_point deadline, start;
    std::jthread baseline_consumer;
    if (baseline) baseline_consumer = std::jthread([&](std::stop_token stop) {
        for (;;) {
            // Acquire done before the final pop: do not miss records published just before done.
            const bool finished = done.load(std::memory_order_acquire);
            const auto n = queue->pop(dequeue_buffer.data(), 256);
            for (std::size_t i = 0; i < n; ++i) receiver.consume(dequeue_buffer.data() + i * o.bytes, o.bytes);
            if ((!n && finished) || stop.stop_requested()) break;
        }
    });
    std::vector<std::jthread> producers;
    producers.reserve(o.producers);
    for (std::size_t id = 0; id < o.producers; ++id) producers.emplace_back([&, id](std::stop_token stop) {
        ready.fetch_add(1, std::memory_order_release);
        while (!go.load(std::memory_order_acquire)) {
            if (stop.stop_requested()) return;
            std::this_thread::yield();
        }
        auto& payload = payloads[id];
        for (std::uint64_t seq = 0; seq < o.messages; ++seq) {
            if (stop.stop_requested() || (seq % 1024 == 0 && Clock::now() >= deadline)) break;
            if (o.interval_us) std::this_thread::sleep_until(start + std::chrono::microseconds{seq * o.interval_us});
            std::fill(payload.begin() + sizeof(Header), payload.end(), static_cast<std::byte>((id + seq) & 255));
            // Timestamp before the FIRST attempt: queue-full retries remain in latency.
            Header header{seq, o.sample_every && seq % o.sample_every == 0 ? now_ns() : 0, id};
            std::memcpy(payload.data(), &header, sizeof(header));
            bool sent = false;
            while (!(sent = baseline ? queue->push(payload.data()) : writers[id]->write_mem(payload.data(), static_cast<std::uint16_t>(payload.size())))) {
                ++retries[id];
                if (stop.stop_requested() || Clock::now() >= deadline) break;
                std::this_thread::yield();
            }
            if (!sent) break;
        }
        if (!baseline) writers[id]->finish();
    });
    while (ready.load(std::memory_order_acquire) != o.producers) std::this_thread::yield();
    start = Clock::now();
    deadline = start + std::chrono::seconds{60};
    go.store(true, std::memory_order_release);
    for (auto& producer : producers) producer.join();
    done.store(true, std::memory_order_release);
    if (baseline) baseline_consumer.join();
    if (reader) reader->stop();
    bool drained = true;
    if (store) {
        store->finish();
        drained = consumer->stop(true);
        store->set_batch_available_callback(nullptr, nullptr);
        store->set_space_available_callback(nullptr, nullptr);
    }
    const double seconds = std::chrono::duration<double>(Clock::now() - start).count();
    example::require(!reader || reader->error_code() == ReadError::none, "reader error/timeout");
    example::require(!store || (drained && store->all_released() && saver->error_code() == StoreError::none), "storage drain failed");
    example::require(receiver.valid && receiver.received == o.producers * o.messages, "integrity/count failure or 60s timeout");
    for (auto n : receiver.next) example::require(n == o.messages, "producer count mismatch");
    return {seconds, receiver.received, std::accumulate(retries.begin(), retries.end(), std::uint64_t{0}), receiver.checksum, std::move(receiver.latency)};
}

int main(int argc, char** argv) try {
    Options o;
    for (int i = 1; i < argc; i += 2) {
        const std::string key = argv[i];
        if (key == "--help") {
            std::cout << "Options (positive integers, except sampling/interval may be zero):\n"
                      << "--messages 200000 --producers 1 --bytes 64 --repeats 5\n"
                      << "--sample-every 0 --interval-us 0 --block-bytes 65536 --blocks 8\n";
            return 0;
        }
        example::require(i + 1 < argc, "missing option value");
        const std::string input = argv[i + 1];
        example::require(!input.empty() && input.find_first_not_of("0123456789") == std::string::npos, "expected unsigned integer");
        const auto value = std::stoull(input);
        if (key == "--messages") o.messages = value;
        else if (key == "--producers") o.producers = value;
        else if (key == "--bytes") o.bytes = value;
        else if (key == "--repeats") o.repeats = value;
        else if (key == "--sample-every") o.sample_every = value;
        else if (key == "--interval-us") o.interval_us = value;
        else if (key == "--block-bytes") o.block_bytes = value;
        else if (key == "--blocks") o.blocks = value;
        else throw std::runtime_error("unknown option: " + key);
    }
    example::require(o.messages > 0 && o.messages <= 10000000 && o.producers > 0 && o.producers <= 32 &&
        o.bytes >= sizeof(Header) && o.bytes <= 65535 && o.repeats > 0 && o.repeats <= 100 &&
        o.blocks >= 2 && o.blocks <= 64 && o.block_bytes >= o.bytes + 2 && o.block_bytes <= 1048576 &&
        o.interval_us <= 100000 && (!o.interval_us || o.messages <= 50000000 / o.interval_us), "options out of range (paced run must fit 50s)");
    const std::vector<std::string> names{"brq_direct", "brq_buffered", "mutex_batch"};
    Options warmup = o;
    warmup.messages = std::min<std::size_t>(o.messages, 10000);
    warmup.interval_us = 0;
    for (const auto& name : names) (void)run(warmup, name);
    std::cout << "transport,trial,producers,messages_per_producer,payload_bytes,block_bytes,blocks,sample_every,interval_us,seconds,msg_per_s,payload_mib_per_s,retries,samples,p50_us,p95_us,p99_us,max_us,checksum\n";
    for (std::size_t trial = 0; trial < o.repeats; ++trial) {
        for (std::size_t index = 0; index < names.size(); ++index) {
            const auto& name = names[(index + trial) % names.size()]; // rotate ordering
            auto r = run(o, name);
            std::sort(r.latency.begin(), r.latency.end());
            auto percentile = [&](std::size_t p) { return r.latency[(r.latency.size() * p + 99) / 100 - 1] / 1000.0; };
            std::cout << std::setprecision(9) << name << ',' << trial << ',' << o.producers << ',' << o.messages << ','
                      << o.bytes << ',' << o.block_bytes << ',' << o.blocks << ',' << o.sample_every << ',' << o.interval_us << ','
                      << r.seconds << ',' << r.received / r.seconds << ',' << r.received * static_cast<double>(o.bytes) / r.seconds / 1048576 << ','
                      << r.retries << ',' << r.latency.size() << ',';
            if (r.latency.empty()) std::cout << ",,,";
            else std::cout << percentile(50) << ',' << percentile(95) << ',' << percentile(99) << ',' << r.latency.back() / 1000.0;
            std::cout << ',' << r.checksum << '\n';
        }
    }
} catch (const std::exception& error) { std::cerr << "benchmark failed: " << error.what() << '\n'; return 1; }
