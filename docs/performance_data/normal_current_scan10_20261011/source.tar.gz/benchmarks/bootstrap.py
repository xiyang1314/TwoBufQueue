#!/usr/bin/env python3
"""Fetch pinned benchmark-only dependencies; no dependencies added to the library."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import tarfile
import urllib.request

BOOST_URL = "https://archives.boost.io/release/1.85.0/source/boost_1_85_0.tar.gz"
BOOST_SHA = "be0d91732d5b0cc6fbb275c7939974457e79b54d6f07ce2e3dfdd68bef883b0b"
MOODY_URL = "https://raw.githubusercontent.com/cameron314/concurrentqueue/v1.0.4/concurrentqueue.h"
MOODY_SHA = "524bc2de581ecc95e632ee6aac2676d6a1029a692a9c1b4a32e4a80608abad5e"


def fetch(url, path, expected=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        print("Downloading", url, flush=True)
        with urllib.request.urlopen(url, timeout=120) as response, path.open("wb") as output:
            shutil.copyfileobj(response, output)
    if expected and hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise RuntimeError(f"SHA256 mismatch: {path}; remove the incomplete cache file and retry")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parents[1] / ".deps")
    parser.add_argument("--cache", type=Path)
    parser.add_argument("--extended", action="store_true", help="Also fetch atomic_queue, rigtorp and MengRao")
    args = parser.parse_args()
    root = args.output.resolve()
    cache = args.cache.resolve() if args.cache else root / "downloads"
    archive = cache / "boost_1_85_0.tar.gz"
    fetch(BOOST_URL, archive, BOOST_SHA)
    target = root / "boost"
    if not (target / ".complete-1.85.0").exists():
        print("Extracting Boost headers and license", flush=True)
        with tarfile.open(archive, "r:gz") as tar:
            for member in tar:
                if not member.isfile():
                    continue
                prefix = "boost_1_85_0/"
                if not member.name.startswith(prefix):
                    continue
                relative = member.name[len(prefix):]
                if not (relative.startswith("boost/") or relative == "LICENSE_1_0.txt"):
                    continue
                dest = (target / relative).resolve()
                dest.relative_to(target.resolve())  # reject path traversal
                dest.parent.mkdir(parents=True, exist_ok=True)
                with tar.extractfile(member) as source, dest.open("wb") as output:
                    shutil.copyfileobj(source, output)
        (target / ".complete-1.85.0").write_text(BOOST_SHA, encoding="utf-8")
    header = cache / "concurrentqueue.h"
    fetch(MOODY_URL, header, MOODY_SHA)
    (root / "moodycamel").mkdir(parents=True, exist_ok=True)
    shutil.copy2(header, root / "moodycamel/concurrentqueue.h")
    fetch("https://raw.githubusercontent.com/cameron314/concurrentqueue/v1.0.4/LICENSE.md", root / "moodycamel/LICENSE.md")
    if args.extended:
        manifest = json.loads(Path(__file__).with_name("extra_dependencies.json").read_text(encoding="utf-8"))
        for name, dep in manifest.items():
            for entry in dep["files"]:
                fetch(entry["url"], root / name / entry["path"], entry["sha256"])
    print("Dependencies ready:", root)


if __name__ == "__main__":
    main()
