#include "../examples/example_support.hpp"
#include "process_metrics.hpp"
#include <boost/lockfree/queue.hpp>
#include <boost/version.hpp>
#include <concurrentqueue.h>
#include <algorithm>
#include <array>
#include <chrono>
#include <iomanip>
#include <iostream>
#include <memory>
#include <mutex>
#include <numeric>
#include <thread>
#if BOOST_VERSION != 108500
#error "The comparison requires pinned Boost 1.85.0"
#endif

using namespace TwoBufQueue;
using Clock = std::chrono::steady_clock;
struct Options {
    std::string transport = "brq_direct", workload = "saturated";
    std::size_t producers = 1, bytes = 32, messages = 200000, batch = 1, sample = 64;
    std::size_t block_bytes = 65536, blocks = 8, interval_us = 100;
    std::size_t publish_count = 1;
    std::size_t burst = 256, pause_us = 1000, slow_every = 256, slow_us = 100;
};
static std::int64_t now_ns() noexcept {
    return std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now().time_since_epoch()).count();
}
template<std::size_t Bytes> struct Record {
    std::uint64_t sequence, producer;
    std::int64_t sent_ns;
    std::array<std::byte, Bytes - 24> body;
};
struct alignas(64) Credit { std::atomic<std::uint64_t> completed{0}; };

template<class T> struct Receiver {
    const Options& o;
    std::vector<std::uint64_t> next;
    std::vector<Credit> credits;
    std::vector<std::int64_t> latency;
    std::uint64_t received = 0, checksum = 0;
    bool valid = true;
    explicit Receiver(const Options& options) : o(options), next(o.producers), credits(o.producers) {
        if (o.sample) latency.reserve(o.producers * ((o.messages - 1) / o.sample + 1));
    }
    void consume(const std::byte* data) noexcept {
        // Decode the header without imposing alignment or making an extra full-payload copy.
        std::uint64_t seq, producer;
        std::int64_t sent;
        std::memcpy(&seq, data, 8);
        std::memcpy(&producer, data + 8, 8);
        std::memcpy(&sent, data + 16, 8);
        if (producer >= next.size()) { valid = false; return; }
        valid &= seq == next[producer]++;
        if (sent) {
            if (latency.size() == latency.capacity()) { valid = false; return; }
            latency.push_back(now_ns() - sent);
        }
        const auto expected = static_cast<std::byte>((seq + producer) & 255);
        for (std::size_t i = 24; i < sizeof(T); ++i) valid &= data[i] == expected;
        checksum += seq + producer + std::to_integer<unsigned>(expected);
        ++received;
        // Charge identical application work per record, independent of callback batching.
        if (o.workload == "slow" && received % o.slow_every == 0)
            std::this_thread::sleep_for(std::chrono::microseconds{o.slow_us});
        credits[producer].completed.store(next[producer], std::memory_order_release);
    }
    template<class Batch> static bool receive(void* context, const Batch& batch) noexcept {
        auto& self = *static_cast<Receiver*>(context);
        self.valid &= example::messages(batch, [&](std::int32_t, const std::byte* p, std::size_t n) noexcept {
            if (n != sizeof(T)) return false;
            self.consume(p);
            return true;
        });
        return true;
    }
    DataCallback callback() { return {[](void* p, DataBatch& b) noexcept { return receive(p, b); }, this}; }
    ReadCallback read_callback() { return {receive<ReadBatch>, this}; }
};

// All adapters copy the SAME record value. No pointer-only shortcut or per-record new.
template<class T> struct Queue {
    virtual ~Queue() = default;
    virtual std::size_t push(std::size_t producer, const T* records, std::size_t count) = 0;
    virtual std::size_t pop(T* records, std::size_t count) = 0;
    virtual std::size_t consume(Receiver<T>& receiver, T* records, std::size_t count) {
        const auto n = pop(records, count);
        for (std::size_t i = 0; i < n; ++i)
            receiver.consume(reinterpret_cast<const std::byte*>(&records[i]));
        return n;
    }
};
#ifdef BRQ_COMPARE_EXTENDED
#include "extended_adapters.hpp"
#endif

template<class T> class MutexQueue final : public Queue<T> {
    std::vector<T> ring_;
    std::size_t head_ = 0, tail_ = 0, size_ = 0;
    std::mutex lock_;
public:
    explicit MutexQueue(std::size_t capacity) : ring_(capacity) {}
    std::size_t push(std::size_t, const T* data, std::size_t count) override {
        std::lock_guard guard(lock_);
        count = std::min(count, ring_.size() - size_);
        for (std::size_t i = 0; i < count; ++i) { ring_[tail_] = data[i]; tail_ = (tail_ + 1) % ring_.size(); }
        size_ += count;
        return count;
    }
    std::size_t pop(T* data, std::size_t count) override {
        std::lock_guard guard(lock_);
        count = std::min(count, size_);
        for (std::size_t i = 0; i < count; ++i) { data[i] = ring_[head_]; head_ = (head_ + 1) % ring_.size(); }
        size_ -= count;
        return count;
    }
};
template<class T> class BoostQueue final : public Queue<T> {
    boost::lockfree::queue<T> queue_;
public:
    explicit BoostQueue(std::size_t capacity) : queue_(capacity) {
        example::require(queue_.is_lock_free(), "Boost queue is not lock-free on this platform");
    }
    std::size_t push(std::size_t, const T* data, std::size_t count) override {
        std::size_t n = 0;
        while (n < count && queue_.bounded_push(data[n])) ++n;
        return n; // Boost MPMC queue has no atomic bulk enqueue; report the accepted prefix.
    }
    std::size_t pop(T* data, std::size_t count) override {
        std::size_t n = 0;
        while (n < count && queue_.pop(data[n])) ++n;
        return n;
    }
};
// Large enough for the supported per-producer credit window at 32-byte payloads.
struct MoodyTraits : moodycamel::ConcurrentQueueDefaultTraits {
    static constexpr std::size_t EXPLICIT_INITIAL_INDEX_SIZE = 4096;
};
template<class T> class MoodyQueue final : public Queue<T> {
    moodycamel::ConcurrentQueue<T, MoodyTraits> queue_;
    std::vector<std::unique_ptr<moodycamel::ProducerToken>> producers_;
    moodycamel::ConsumerToken consumer_;
public:
    MoodyQueue(std::size_t capacity, std::size_t producers)
        // Each producer is credit-limited to capacity/producers, so preallocate
        // (ceil(per-producer-window / block) + 1) * producers blocks, not P times
        // the entire aggregate window. Includes the upstream partial-block slack.
        : queue_(capacity / producers, producers, 0), consumer_(queue_) {
        for (std::size_t i = 0; i < producers; ++i)
            producers_.push_back(std::make_unique<moodycamel::ProducerToken>(queue_));
    }
    std::size_t push(std::size_t producer, const T* data, std::size_t count) override {
        if (count == 1) return queue_.try_enqueue(*producers_[producer], *data) ? 1 : 0;
        return queue_.try_enqueue_bulk(*producers_[producer], data, count) ? count : 0;
    }
    std::size_t pop(T* data, std::size_t count) override {
        if (count == 1) return queue_.try_dequeue(consumer_, *data) ? 1 : 0;
        return queue_.try_dequeue_bulk(consumer_, data, count);
    }
};
template<class T, std::uint32_t PublishCount> class BrqQueue final : public Queue<T> {
public:
    using RecordWriter = Writer<PublishCount, true>;
    std::vector<std::unique_ptr<WriterPool>> pools;
    std::vector<std::unique_ptr<WriterQueue>> queues;
    std::vector<std::unique_ptr<RecordWriter>> writers;
    std::unique_ptr<BigMemoryStore> store;
    std::unique_ptr<SaveMemoryAdapter> saver;
    std::unique_ptr<ReadWorker> reader;
    std::unique_ptr<QueueReader> consumer;
    BrqQueue(const Options& o, DataCallback callback, ReadCallback read_callback) {
        for (std::size_t i = 0; i < o.producers; ++i) {
            pools.push_back(std::make_unique<WriterPool>(o.blocks, o.blocks, SpscBlockFactory<SpscWriteBlock>{o.block_bytes}));
            queues.push_back(std::make_unique<WriterQueue>(*pools.back(), 256, writer_queue_callbacks));
        writers.push_back(std::make_unique<RecordWriter>(queues.back().get(), static_cast<std::int32_t>(i)));
        }
        auto handler = read_callback;
        if (o.transport == "brq_buffered") {
            BigMemoryStoreConfig config;
            config.block_size = config.max_batch_bytes = o.block_bytes;
            config.initial_block_count = config.max_block_count = o.blocks * o.producers;
            config.batch_queue_capacity = 64;
            store = std::make_unique<BigMemoryStore>(config);
            saver = std::make_unique<SaveMemoryAdapter>(*store);
            handler = saver->completed_callback();
        }
        ReadConfig config;
        config.finish_timeout = std::chrono::seconds{30};
        reader = std::make_unique<ReadWorker>(config, handler, handler);
        for (std::size_t i = 0; i < o.producers; ++i)
            example::require(reader->add_writer(writers[i].get()), "BRQ registration failed");
        if (store) {
            consumer = std::make_unique<QueueReader>(*store, callback);
            store->set_batch_available_callback([](void* p) noexcept { static_cast<QueueReader*>(p)->notify(); }, consumer.get());
            store->set_space_available_callback([](void* p) noexcept { static_cast<ReadWorker*>(p)->notify_memory_available(); }, reader.get());
            example::require(consumer->start(), "BRQ consumer start failed");
        }
        example::require(reader->start(), "BRQ reader start failed");
    }
    std::size_t push(std::size_t id, const T* data, std::size_t count) override {
        std::size_t n = 0;
        while (n < count && writers[id]->write(data[n])) ++n;
        // Publish even a partial accepted batch before credit/backpressure retries.
        // This intentionally includes flush cost, including after an exact batch.
        if constexpr (PublishCount != 1) writers[id]->flush();
        return n;
    }
    std::size_t pop(T*, std::size_t) override { return 0; }
    void finish(std::size_t id) { writers[id]->finish(); }
    void drain() {
        reader->stop();
        bool drained = true;
        if (store) {
            store->finish();
            drained = consumer->stop(true, std::chrono::seconds{30});
            store->set_batch_available_callback(nullptr, nullptr);
            store->set_space_available_callback(nullptr, nullptr);
        }
        example::require(reader->error_code() == ReadError::none, "BRQ drain failed");
        example::require(!store || (drained && store->all_released() && saver->error_code() == StoreError::none), "buffered drain failed");
    }
};
struct alignas(64) ProducerStats {
    std::uint64_t retries = 0;
    std::vector<std::int64_t> calls;
};
static double percentile(std::vector<std::int64_t>& data, std::size_t p) {
    if (data.empty()) return -1;
    const auto index = (data.size() * p + 99) / 100 - 1;
    std::nth_element(data.begin(), data.begin() + index, data.end());
    return data[index] / 1000.0;
}

template<std::size_t Bytes, std::uint32_t PublishCount = 1> int run(const Options& o) {
    using T = Record<Bytes>;
    static_assert(sizeof(T) == Bytes && std::is_trivially_copyable_v<T>);
    Receiver<T> receiver(o);
    const auto capacity = o.producers * o.blocks * (o.block_bytes / (Bytes + 2));
    std::unique_ptr<Queue<T>> queue;
    BrqQueue<T, PublishCount>* brq = nullptr;
    if (o.transport == "brq_direct" || o.transport == "brq_buffered") {
        auto q = std::make_unique<BrqQueue<T, PublishCount>>(o, receiver.callback(), receiver.read_callback());
        brq = q.get(); queue = std::move(q);
    } else if (o.transport == "moodycamel") queue = std::make_unique<MoodyQueue<T>>(capacity, o.producers);
    else if (o.transport == "boost") queue = std::make_unique<BoostQueue<T>>(capacity);
    else if (o.transport == "mutex") queue = std::make_unique<MutexQueue<T>>(capacity);
    #ifdef BRQ_COMPARE_EXTENDED
    else if (o.transport == "atomic_queue") queue = std::make_unique<AtomicQueueAdapter<T>>(capacity);
    else if (o.transport == "rigtorp") queue = std::make_unique<ShardedAdapter<T, RigtorpChannel>>(capacity, o.producers);
    else if (o.transport == "mengrao") queue = std::make_unique<ShardedAdapter<T, MengRaoChannel>>(capacity, o.producers);
#endif
    else throw std::runtime_error("unknown transport (extended adapters require BRQ_COMPARE_EXTENDED=ON)");
    std::atomic<bool> go{false}, done{false};
    std::atomic<std::size_t> ready{0};
    std::vector<ProducerStats> stats(o.producers);
    std::vector<std::vector<T>> prepared(o.producers, std::vector<T>(o.batch));
    for (auto& s : stats) if (o.sample) s.calls.reserve((o.messages - 1) / o.sample + 1);
    std::vector<T> output(o.batch == 1 ? 1 : 256);
    Clock::time_point start, deadline;
    std::jthread consuming;
    if (!brq) consuming = std::jthread([&](std::stop_token stop) {
        // Stock nonblocking queues have no wakeup: poll + yield, reported in CPU metrics.
        for (;;) {
            const bool finished = done.load(std::memory_order_acquire);
            const auto n = queue->consume(receiver, output.data(), output.size());
            if ((!n && finished) || stop.stop_requested()) break;
            if (!n) std::this_thread::yield();
        }
    });
    std::vector<std::jthread> producers;
    producers.reserve(o.producers);
    for (std::size_t id = 0; id < o.producers; ++id) producers.emplace_back([&, id](std::stop_token stop) {
        ready.fetch_add(1, std::memory_order_release);
        while (!go.load(std::memory_order_acquire)) { if (stop.stop_requested()) return; std::this_thread::yield(); }
        auto& records = prepared[id];
        for (std::size_t seq = 0; seq < o.messages;) {
            if (stop.stop_requested() || Clock::now() >= deadline) break;
            auto n = std::min(o.batch, o.messages - seq);
            if (o.workload == "paced") std::this_thread::sleep_until(start + std::chrono::microseconds{seq * o.interval_us});
            if (o.workload == "burst") {
                if (seq && seq % o.burst == 0) std::this_thread::sleep_for(std::chrono::microseconds{o.pause_us});
                n = std::min(n, o.burst - seq % o.burst);
            }
            for (std::size_t i = 0; i < n; ++i) {
                auto& r = records[i];
                r.sequence = seq + i; r.producer = id; r.sent_ns = 0;
                r.body.fill(static_cast<std::byte>((seq + i + id) & 255));
            }
            const bool sampled_call = o.sample && seq % o.sample == 0;
            for (std::size_t i = 0; i < n; ++i)
                if (o.sample && (seq + i) % o.sample == 0) records[i].sent_ns = now_ns();
            const auto before = sampled_call ? now_ns() : 0;
            std::size_t sent = 0;
            while (sent < n) {
                const auto outstanding = seq + sent - receiver.credits[id].completed.load(std::memory_order_acquire);
                const auto window = capacity / o.producers;
                const auto allowed = std::min(n - sent, window - outstanding);
                const auto accepted = allowed ? queue->push(id, records.data() + sent, allowed) : 0;
                sent += accepted;
                if (sent == n) break;
                ++stats[id].retries;
                if (stop.stop_requested() || Clock::now() >= deadline) break;
                std::this_thread::yield();
            }
            if (sampled_call) stats[id].calls.push_back(now_ns() - before);
            if (sent != n) break;
            seq += n;
        }
        if (brq) brq->finish(id);
    });
    while (ready.load(std::memory_order_acquire) != o.producers) std::this_thread::yield();
    const auto cpu_start = benchmark::cpu_seconds();
    start = Clock::now(); deadline = start + std::chrono::seconds{120};
    go.store(true, std::memory_order_release);
    for (auto& producer : producers) producer.join();
    done.store(true, std::memory_order_release);
    if (brq) brq->drain(); else consuming.join();
    const auto seconds = std::chrono::duration<double>(Clock::now() - start).count();
    const auto cpu = benchmark::cpu_seconds() - cpu_start;
    const auto rss = benchmark::peak_rss_mib();
    example::require(receiver.valid && receiver.received == o.producers * o.messages, "count, content, order or deadline failure");
    for (auto n : receiver.next) example::require(n == o.messages, "producer count mismatch");
    std::vector<std::int64_t> calls;
    std::uint64_t retries = 0;
    for (auto& s : stats) { retries += s.retries; calls.insert(calls.end(), s.calls.begin(), s.calls.end()); }
    std::cout << "transport,workload,producers,payload_bytes,messages_per_producer,batch,sample_every,capacity_records,seconds,msg_per_s,cpu_seconds,cpu_cores,peak_rss_mib,retries,latency_samples,p50_us,p95_us,p99_us,max_us,call_samples,call_p50_us,call_p99_us,checksum,boost_version,publish_count\n";
    std::cout << std::setprecision(9) << o.transport << ',' << o.workload << ',' << o.producers << ',' << Bytes << ','
        << o.messages << ',' << o.batch << ',' << o.sample << ',' << capacity << ',' << seconds << ','
        << receiver.received / seconds << ',' << cpu << ',' << cpu / seconds << ',' << rss << ',' << retries << ','
        << receiver.latency.size() << ',' << percentile(receiver.latency, 50) << ',' << percentile(receiver.latency, 95) << ','
        << percentile(receiver.latency, 99) << ',' << percentile(receiver.latency, 100) << ',' << calls.size() << ','
        << percentile(calls, 50) << ',' << percentile(calls, 99) << ',' << receiver.checksum << ',' << BOOST_LIB_VERSION << ',' << o.publish_count << '\n';
    return 0;
}
int main(int argc, char** argv) try {
    Options o;
    for (int i = 1; i < argc; i += 2) {
        const std::string key = argv[i];
        if (key == "--help") {
            std::cout << "--transport brq_direct|brq_buffered|moodycamel|boost|mutex --workload saturated|paced|burst|slow\n"
                "--producers 1 --bytes 32|256|1024 --messages 200000 --batch 1|32 --sample-every 64 (0 disables clocks)\n"
                "--extended transports: atomic_queue|rigtorp|mengrao (build option required)\n"
                "--publish-count 1|32 (BRQ: 32 flushes each accepted batch)\n"
                "--block-bytes 65536 --blocks 8 --interval-us 100 --burst 256 --pause-us 1000 --slow-every 256 --slow-us 100\n";
            return 0;
        }
        example::require(i + 1 < argc, "missing value");
        if (key == "--transport") { o.transport = argv[i + 1]; continue; }
        if (key == "--workload") { o.workload = argv[i + 1]; continue; }
        const std::string input = argv[i + 1];
        example::require(!input.empty() && input.find_first_not_of("0123456789") == std::string::npos, "expected unsigned integer");
        const auto v = std::stoull(input);
        if (key == "--producers") o.producers = v;
        else if (key == "--bytes") o.bytes = v;
        else if (key == "--messages") o.messages = v;
        else if (key == "--publish-count") o.publish_count = v;
        else if (key == "--batch") o.batch = v;
        else if (key == "--sample-every") o.sample = v;
        else if (key == "--block-bytes") o.block_bytes = v;
        else if (key == "--blocks") o.blocks = v;
        else if (key == "--interval-us") o.interval_us = v;
        else if (key == "--burst") o.burst = v;
        else if (key == "--pause-us") o.pause_us = v;
        else if (key == "--slow-every") o.slow_every = v;
        else if (key == "--slow-us") o.slow_us = v;
        else throw std::runtime_error("unknown option: " + key);
    }
    example::require(o.producers >= 1 && o.producers <= 8 && o.messages >= 1 && o.messages <= 100000000 &&
        (o.batch == 1 || o.batch == 32) && o.blocks >= 2 && o.blocks <= 8 && o.block_bytes >= o.bytes + 2 && o.block_bytes <= 65536 &&
        o.interval_us >= 1 && o.interval_us <= 10000 && o.burst >= 1 && o.pause_us <= 10000 && o.slow_every >= 1 && o.slow_us <= 10000,
        "options out of range");
    example::require(o.workload == "saturated" || o.workload == "paced" || o.workload == "burst" || o.workload == "slow", "unknown workload");
    example::require(o.workload != "paced" || (o.batch == 1 && o.messages <= 100000000 / o.interval_us), "paced requires batch=1 and <=100s schedule");
    example::require(o.publish_count == 1 || (o.publish_count == 32 &&
        (o.transport == "brq_direct" || o.transport == "brq_buffered")), "publish-count 32 is BRQ only");
    if (o.publish_count == 32) {
        if (o.bytes == 32) return run<32, 32>(o);
        if (o.bytes == 256) return run<256, 32>(o);
        if (o.bytes == 1024) return run<1024, 32>(o);
    }
    if (o.bytes == 32) return run<32>(o);
    if (o.bytes == 256) return run<256>(o);
    if (o.bytes == 1024) return run<1024>(o);
    throw std::runtime_error("payload must be 32, 256 or 1024 bytes");
} catch (const std::exception& error) { std::cerr << "comparison failed: " << error.what() << '\n'; return 1; }
