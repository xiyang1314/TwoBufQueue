#!/usr/bin/env python3
"""运行 Release 版可执行文件，保留原始结果以及主机和构建信息。"""
import argparse
import csv
import datetime
import io
import json
import os
from pathlib import Path
import platform
import statistics
import subprocess


def capture(command, cwd=None):
    try:
        return subprocess.check_output(command, cwd=cwd, text=True, stderr=subprocess.STDOUT).strip()
    except (OSError, subprocess.CalledProcessError) as error:
        return str(error)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("executable", type=Path)
    parser.add_argument("--output", type=Path, default=Path("benchmark-results"))
    parser.add_argument("--quick", action="store_true", help="Small correctness/reproducibility run, not publishable performance evidence")
    parser.add_argument("--note", default="", help="Power plan, affinity, background load and other environment notes")
    args = parser.parse_args()
    executable = args.executable.resolve(strict=True)
    # A fresh directory avoids silently mixing different machines or configurations.
    args.output.mkdir(parents=True, exist_ok=False)
    source = Path(__file__).resolve().parents[1]
    cache = next((p / "CMakeCache.txt" for p in [executable.parent, *executable.parents]
                  if (p / "CMakeCache.txt").is_file()), None)
    cache_text = cache.read_text(encoding="utf-8", errors="replace") if cache else "unavailable"
    commands = []
    metadata = {
        "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "platform": platform.platform(), "machine": platform.machine(),
        "processor": platform.processor(), "logical_cpus": os.cpu_count(),
        "python": platform.python_version(), "executable": str(executable),
        "git_head": capture(["git", "rev-parse", "HEAD"], source),
        "git_status": capture(["git", "status", "--short"], source),
        "cmake_cache": cache_text, "commands": commands,
        "notes": "No CPU affinity requested. Record CPU model, power plan, RAM, competing load and thermal state before publishing."
    }
    metadata["user_note"] = args.note
    if platform.system() == "Windows":
        metadata["cpu_details"] = capture(["powershell", "-NoProfile", "-Command", "Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors | ConvertTo-Json"])
    elif Path("/proc/cpuinfo").exists():
        metadata["cpu_details"] = Path("/proc/cpuinfo").read_text()
    scenarios = [(1, 64), (4, 64)] if args.quick else [(p, b) for p in (1, 4) for b in (32, 256, 1024)]
    all_rows = []
    try:
        for producers, payload in scenarios:
            command = [str(executable), "--messages", "10000" if args.quick else "500000",
                       "--producers", str(producers), "--bytes", str(payload), "--repeats", "2" if args.quick else "5"]
            commands.append(command)
            output = subprocess.check_output(command, text=True, timeout=900)
            (args.output / f"throughput-p{producers}-b{payload}.csv").write_text(output, encoding="utf-8")
            all_rows.extend(csv.DictReader(io.StringIO(output)))
        # Saturated sampled latency and a separate paced scenario. Do not mix these
        # instrumented throughput values with uninstrumented throughput results.
        for interval in (0, 100):
            command = [str(executable), "--messages", "2000" if args.quick else "20000",
                       "--producers", "1", "--bytes", "64", "--repeats", "2" if args.quick else "5",
                       "--sample-every", "1", "--interval-us", str(interval)]
            commands.append(command)
            output = subprocess.check_output(command, text=True, timeout=900)
            (args.output / f"latency-interval{interval}.csv").write_text(output, encoding="utf-8")
            all_rows.extend(csv.DictReader(io.StringIO(output)))
    finally:
        (args.output / "environment.json").write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")
    groups = {}
    for row in all_rows:
        key = tuple(row[k] for k in ("transport", "producers", "payload_bytes", "sample_every", "interval_us"))
        groups.setdefault(key, []).append(row)
    summary = ["# 本地基准结果", "", "本报告根据原始 CSV 生成；测量包含数据校验和排空，具体口径见基准方法说明。", "",
               "| 方案 | 生产者数 | 字节数 | 采样间隔 | 提交间隔 µs | 吞吐中位数 Mmsg/s | 吞吐范围 Mmsg/s | 每轮 p99 的中位数 µs |",
               "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for key, rows in groups.items():
        rates = [float(row["msg_per_s"]) / 1e6 for row in rows]
        latencies = [float(row["p99_us"]) for row in rows if row["p99_us"]]
        p99 = f"{statistics.median(latencies):.3f}" if latencies else "—"
        summary.append("| " + " | ".join(key) + f" | {statistics.median(rates):.3f} | {min(rates):.3f}–{max(rates):.3f} | {p99} |")
    if args.quick:
        summary += ["", "仅为快速冒烟检查，运行时间过短，不能用于对外发布性能结论。"]
    if any(float(row["seconds"]) < 0.5 for row in all_rows):
        summary += ["", "部分测量不足 0.5 秒；发布性能结论前应增大 --messages 并重新测量。"]
    if args.note:
        summary += ["", "环境备注：" + args.note]
    (args.output / "SUMMARY.md").write_text("\n".join(summary) + "\n", encoding="utf-8")
    print(f"原始 CSV、environment.json 和 SUMMARY.md 已保存到 {args.output.resolve()}")


if __name__ == "__main__":
    main()
