#pragma once
#include <atomic_queue/atomic_queue.h>
#include <rigtorp/SPSCQueue.h>
#include <cstdint>
#include <SPSCVarQueue.h>

// Same full record on input. AtomicQueueB2 supports non-atomic record types.
template<class T> class AtomicQueueAdapter final : public Queue<T> {
    atomic_queue::AtomicQueueB2<T> queue_;
public:
    explicit AtomicQueueAdapter(std::size_t capacity) : queue_(static_cast<unsigned>(capacity)) {}
    std::size_t push(std::size_t, const T* data, std::size_t count) override {
        std::size_t n = 0;
        while (n < count && queue_.try_push(data[n])) ++n;
        return n;
    }
    std::size_t pop(T* data, std::size_t count) override {
        std::size_t n = 0;
        while (n < count && queue_.try_pop(data[n])) ++n;
        return n;
    }
};

template<class T> struct RigtorpChannel {
    rigtorp::SPSCQueue<T> queue;
    explicit RigtorpChannel(std::size_t capacity) : queue(capacity) {}
    bool push(const T& value) { return queue.try_push(value); }
    const std::byte* front() { return reinterpret_cast<const std::byte*>(queue.front()); }
    void pop() { queue.pop(); }
};

template<class T> struct MengRaoChannel {
    // Upstream uses GNU inline assembly and plain shared indexes; restrict this
    // unmodified implementation to the x86/GNU-style compiler experiment.
    // 1 MiB accommodates the maximum supported per-writer credit window,
    // including its 8-byte header and 64-byte message granularity.
    SPSCVarQueue<1u << 20> queue;
    explicit MengRaoChannel(std::size_t) {}
    bool push(const T& value) {
        auto* h = queue.alloc(static_cast<std::uint16_t>(sizeof(T)));
        if (!h) return false;
        h->msg_type = 0; h->userdata = 0;
        std::memcpy(reinterpret_cast<std::byte*>(h) + sizeof(*h), &value, sizeof(T));
        queue.push();
        return true;
    }
    const std::byte* front() {
        auto* h = queue.front();
        return h ? reinterpret_cast<const std::byte*>(h) + sizeof(*h) : nullptr;
    }
    void pop() { queue.pop(); }
};

// One SPSC channel per producer. A single consumer rotates between channels;
// at most 32 records are consumed from one channel per visit, including in
// submit-1 runs. This is consumer batching, not a native bulk producer API.
template<class T, template<class> class Channel> class ShardedAdapter final : public Queue<T> {
    std::vector<std::unique_ptr<Channel<T>>> channels_;
    std::size_t next_ = 0;
public:
    ShardedAdapter(std::size_t capacity, std::size_t producers) {
        for (std::size_t i = 0; i < producers; ++i)
            channels_.push_back(std::make_unique<Channel<T>>(capacity / producers));
    }
    std::size_t push(std::size_t producer, const T* data, std::size_t count) override {
        std::size_t n = 0;
        while (n < count && channels_[producer]->push(data[n])) ++n;
        return n;
    }
    std::size_t pop(T*, std::size_t) override { return 0; } // consume in place below
    std::size_t consume(Receiver<T>& receiver, T*, std::size_t count) override {
        std::size_t n = 0;
        for (std::size_t visited = 0; visited < channels_.size() && n < count; ++visited) {
            auto& q = *channels_[next_];
            next_ = (next_ + 1 == channels_.size()) ? 0 : next_ + 1;
            for (std::size_t taken = 0; taken < 32 && n < count; ++taken) {
                const auto* p = q.front();
                if (!p) break;
                receiver.consume(p); // validate before pop permits producer reuse
                q.pop();
                ++n;
            }
        }
        return n;
    }
};
