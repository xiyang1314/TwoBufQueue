import argparse, csv, hashlib, json, statistics, subprocess, time
from pathlib import Path
ap=argparse.ArgumentParser()
ap.add_argument('--exe',type=Path,required=True)
ap.add_argument('--out',type=Path,required=True)
ap.add_argument('--messages',type=int,default=20000000)
ap.add_argument('--repetitions',type=int,default=7)
a=ap.parse_args(); a.out.mkdir(parents=True,exist_ok=True)
variants=[('brq_direct',1),('brq_direct',32),('brq_buffered',1),('brq_buffered',32),('moodycamel',1)]
def run(t,p,m,byte=32,batch=32):
    cmd=[str(a.exe.resolve()),'--transport',t,'--publish-count',str(p),'--producers','4','--bytes',str(byte),'--batch',str(batch),'--messages',str(m),'--sample-every','0']
    r=subprocess.run(cmd,capture_output=True,text=True,check=True,timeout=150)
    return next(csv.DictReader(r.stdout.splitlines()))
# Odd record counts check trailing Flush, crossing block boundaries and partial batches.
for t in ['brq_direct','brq_buffered']:
    for byte in [32,256,1024]:
        for batch in [1,32]: run(t,32,3001,byte,batch)
print('12 batch-publication integrity checks passed',flush=True)
for t,p in variants: run(t,p,500000)
rows=[]
for rep in range(a.repetitions):
    order=variants[rep%len(variants):]+variants[:rep%len(variants)]
    for t,p in order:
        row=run(t,p,a.messages);row['trial']=rep+1;rows.append(row)
        with (a.out/'raw.csv').open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
        print(f"{rep+1}: {t} publish={p} {float(row['msg_per_s'])/1e6:.2f} M/s",flush=True)
summary=[]
for t,p in variants:
    r=[x for x in rows if x['transport']==t and int(x['publish_count'])==p]
    vals=[float(x['msg_per_s'])/1e6 for x in r]
    summary.append(dict(transport=t,publish_count=p,median_mps=statistics.median(vals),min_mps=min(vals),max_mps=max(vals),cpu_cores=statistics.median(float(x['cpu_cores']) for x in r)))
(a.out/'summary.json').write_text(json.dumps(summary,indent=2))
(a.out/'run.json').write_text(json.dumps(dict(messages=a.messages,repetitions=a.repetitions,exe_sha256=hashlib.sha256(a.exe.read_bytes()).hexdigest(),timestamp=time.strftime('%Y-%m-%dT%H:%M:%S'),smoke_checks=12),indent=2))
print(json.dumps(summary,indent=2),flush=True)
