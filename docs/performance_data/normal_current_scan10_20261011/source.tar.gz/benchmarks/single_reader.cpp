// Compare the unchanged multi-source implementation bound to one Writer with
// the dedicated single-source implementation. Both validate all 32-byte payloads.
#include <TwoBufQueue.hpp>
#include <array>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string_view>
#include <thread>
using namespace TwoBufQueue;

struct Payload { std::uint64_t sequence; std::array<std::byte,24> bytes; };
static_assert(sizeof(Payload) == 32);
struct Collector {
    std::uint64_t count = 0;
    bool valid = true;
    void begin_read_complete(std::int64_t) noexcept {}
    bool read_complete(SpscWriteBlock* block) noexcept {
        const auto bytes = block->readable(); return read_current(block,bytes.data(),bytes.size());
    }
    void end_read_complete() noexcept {}
    void begin_read_current(std::int64_t) noexcept {}
    bool read_current(SpscWriteBlock* block, const std::byte* ptr, std::size_t size) noexcept {
        if (block->source_id() != 0 || size % 34) { valid = false; return true; }
        for (std::size_t offset = 0; offset < size; offset += 34) {
            Payload value;
            std::memcpy(&value,ptr + offset + 2,sizeof(value));
            valid &= ptr[offset] == std::byte{32} && ptr[offset+1] == std::byte{0} && value.sequence == count;
            for (auto byte : value.bytes) valid &= byte == std::byte{0x5a};
            ++count;
        }
        return true;
    }
    void end_read() noexcept {}
};
static void require(bool ok) { if (!ok) std::abort(); }
static ReadConfig config() {
    ReadConfig result;
    result.idle_spin_count = 1000;
    result.idle_rescan_interval = std::chrono::milliseconds{5};
    result.idle_rescan_max_interval = std::chrono::milliseconds{30};
    return result;
}

template<bool Single>
static void measure(std::string_view mode, std::uint64_t messages, unsigned batch) {
    WriterPool pool(8,8,SpscBlockFactory<SpscWriteBlock>{65536});
    WriterQueue queue(pool,16,writer_queue_callbacks);
    Writer<> writer(&queue,0);
    Collector collector;
    AutoResetEvent event;
    Payload payload{}; payload.bytes.fill(std::byte{0x5a});
    double elapsed = 0;
    std::uint64_t retries = 0;
    initialize_fast_epoch_clock();
    if (mode == "service") {
        const std::atomic<bool> cancel{false};
        auto run = [&](auto& service) {
            service.prepare_start();
            (void)service.read_once(true,cancel);
            event.reset();
            const auto start = std::chrono::steady_clock::now();
            for (std::uint64_t i = 0; i != messages; ++i) {
                payload.sequence = i; require(writer.write(payload)); writer.flush();
                require(event.try_wait());
                if constexpr (Single) (void)service.read_once(true,cancel);
                else (void)service.read_notified(cancel);
            }
            writer.finish(); (void)service.read_once(true,cancel);
            elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
            service.detach_completed_callbacks();
            require(service.error_code() == ReadError::none);
        };
        if constexpr (Single) {
            SingleReadService service(config(),collector,event,writer); run(service);
        } else {
            ReadService service(config(),collector,event); require(service.add_writer(&writer)); run(service);
        }
    } else {
        auto run = [&](auto& worker) {
            require(worker.start());
            const auto start = std::chrono::steady_clock::now();
            for (std::uint64_t i = 0; i != messages; ++i) {
                payload.sequence = i;
                while (!writer.write(payload)) { ++retries; std::this_thread::yield(); }
                if ((i+1) % batch == 0) writer.flush();
            }
            writer.finish(); worker.stop();
            elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
            require(worker.error_code() == ReadError::none);
        };
        if constexpr (Single) { SingleReadWorker worker(config(),collector,writer); run(worker); }
        else { ReadWorker worker(config(),collector); require(worker.add_writer(&writer)); run(worker); }
    }
    require(collector.valid && collector.count == messages && pool.all_released());
    std::printf("%.*s,%s,%llu,%u,%.9f,%.3f,%llu\n",static_cast<int>(mode.size()),mode.data(),
                Single ? "single" : "multi_one",static_cast<unsigned long long>(messages),batch,
                elapsed,elapsed * 1e9 / static_cast<double>(messages),static_cast<unsigned long long>(retries));
}
int main(int argc, char** argv) {
    if (argc != 5) return 2;
    const std::string_view mode = argv[1], path = argv[2];
    const auto messages = std::strtoull(argv[3],nullptr,10);
    const auto batch = static_cast<unsigned>(std::strtoul(argv[4],nullptr,10));
    if ((mode != "service" && mode != "worker") || !messages || !batch ||
        (mode == "service" && batch != 1)) return 2;
    if (path == "single") measure<true>(mode,messages,batch);
    else if (path == "multi_one") measure<false>(mode,messages,batch);
    else return 2;
}
