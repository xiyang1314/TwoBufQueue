#!/usr/bin/env python3
"""根据原始测量 CSV 绘制性能对比图；发布用环境依赖 matplotlib==3.10.8。"""
import argparse
import csv
import json
from pathlib import Path
import statistics
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Patch

NAMES = ["brq_direct", "brq_buffered", "moodycamel", "boost", "mutex"]
LABELS = ["BRQ 直接模式", "BRQ 缓冲模式", "moodycamel", "Boost.Lockfree", "互斥锁批处理"]
COLORS = ["#2563eb", "#0891b2", "#d97706", "#7c3aed", "#64748b"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path)
    args = parser.parse_args()
    rows = list(csv.DictReader((args.results / "raw.csv").open(encoding="utf-8")))
    meta = json.loads((args.results / "environment.json").read_text(encoding="utf-8"))
    if not meta.get("complete") or meta["profile"] == "smoke":
        raise ValueError("需要完整的非冒烟测量结果")
    names = meta.get("transports", NAMES)
    labels_by_name = dict(zip(NAMES, LABELS))
    labels_by_name.update(atomic_queue="atomic_queue B2", rigtorp="rigtorp（每个写端）", mengrao="MengRao Var（每个写端）")
    labels = [labels_by_name[n] for n in names]
    colors = (COLORS + ["#059669", "#db2777", "#b45309"])[:len(names)]
    def values(case, name, field):
        result = [float(r[field]) for r in rows if r["case"] == case and r["transport"] == name]
        if len(result) != meta["trials"]:
            raise ValueError(f"{case}/{name} 缺少测量轮次")
        return result
    available_fonts = {font.name for font in font_manager.fontManager.ttflist}
    chinese_font = next((name for name in ("Noto Sans CJK SC", "Noto Sans SC", "Microsoft YaHei", "SimHei")
                         if name in available_fonts), None)
    if chinese_font is None:
        raise RuntimeError("未找到中文字体；请安装 Noto Sans CJK SC、Noto Sans SC、微软雅黑或黑体")
    plt.rcParams.update({"font.family": chinese_font, "font.size": 10, "axes.spines.top": False,
                         "axes.spines.right": False, "svg.fonttype": "none"})
    fig, axes = plt.subplots(2, 2, figsize=(13, 8.4))
    throughput, cpu, latency, memory = axes.flat
    for batch, offset, hatch, alpha in [(1, -0.19, "//", 0.6), (32, 0.19, None, 1)]:
        for i, name in enumerate(names):
            samples = [v / 1e6 for v in values(f"saturated-p4-b32-batch{batch}", name, "msg_per_s")]
            mid = statistics.median(samples)
            throughput.barh(i + offset, mid, height=.34, color=colors[i], hatch=hatch, alpha=alpha,
                            xerr=[[mid - min(samples)], [max(samples) - mid]], capsize=2)
    throughput.set(yticks=range(len(names)), yticklabels=labels, xlabel="已消费消息吞吐量（百万条/秒，越高越好）",
                   title="吞吐量 · 4 个生产者 · 32 字节数据")
    throughput.invert_yaxis()
    throughput.legend(handles=[Patch(facecolor="#94a3b8", hatch="//", label="每次提交 1 条"), Patch(facecolor="#475569", label="每次提交 32 条")], loc="lower right", fontsize=9)
    for ax, field, title, xlabel in [
        (cpu, "cpu_cores", "CPU 使用量 · 相同负载 · 每次提交 32 条", "进程 CPU 秒数/墙钟秒数"),
        (memory, "peak_rss_mib", "进程内存 · 相同负载 · 每次提交 32 条", "峰值常驻内存 MiB（含初始化）")]:
        mids = [statistics.median(values("saturated-p4-b32-batch32", name, field)) for name in names]
        ax.barh(range(len(names)), mids, color=colors)
        ax.set(yticks=range(len(names)), yticklabels=labels, title=title, xlabel=xlabel)
        ax.invert_yaxis()
        for i, value in enumerate(mids): ax.text(value, i, f"  {value:.2f}", va="center", fontsize=9)
        ax.set_xlim(0, max(mids) * 1.22)
    for i, name in enumerate(names):
        samples = [v / 1000 for v in values("paced-p1", name, "p99_us")]
        mid = statistics.median(samples)
        latency.plot(mid, i, "o", color=colors[i], markersize=8)
        latency.plot([min(samples), max(samples)], [i, i], color=colors[i], linewidth=2)
        latency.annotate(f"{mid:.3f} ms", (mid, i), xytext=(8, 7), textcoords="offset points", fontsize=9)
    latency.set(xscale="log", yticks=range(len(names)), yticklabels=labels,
                title="定速输入 p99 · 1 个生产者 · 目标每秒 1 万条",
                xlabel="端到端 p99，毫秒 · 对数坐标（越低越好）")
    latency.invert_yaxis()
    lo, hi = latency.get_xlim()
    latency.set_xlim(lo / 1.2, hi * 3)
    for ax in axes.flat:
        ax.grid(axis="x", alpha=.18)
        ax.set_axisbelow(True)
    fig.suptitle("历史队列对比：吞吐量、延时与资源开销", fontsize=17, fontweight="bold", y=.985)
    platform_label = "Windows" if meta["platform"].startswith("Windows") else "Linux / WSL" if "microsoft" in meta["platform"].lower() else "Linux"
    if platform_label == "Windows":
        try:
            hardware = json.loads(meta["cpu"])
            if isinstance(hardware, list): hardware = hardware[0]
            model = hardware["Name"].replace("(R)", "").replace("(TM)", "").replace(" CPU", "").split(" @")[0]
            platform_label += f" · {model} ({hardware['NumberOfCores']}C/{hardware['NumberOfLogicalProcessors']}T)"
        except (ValueError, KeyError, TypeError):
            pass  # WMI 不可用时保留操作系统名称，硬件细节仍记录在元数据中。
    fig.text(.5, .935, f"{platform_label} · {meta['trials']} 轮独立进程测量 · 中位数及吞吐量/延时范围 · {meta['utc'][:10]}", ha="center", fontsize=10)
    fig.text(.5, .035, "均处理完整记录、限制在途数量并校验结果；各库的元数据和轮询策略不同。BRQ 缓冲模式额外使用线程和资源池。\n"
             "定速输入从实际提交时计时，未做遗漏协调校正。仅代表单机结果，不能据此断定队列的普遍排名；详见原始 CSV 和方法说明。", ha="center", fontsize=9, color="#475569")
    fig.tight_layout(rect=(0, .085, 1, .925), h_pad=2.5, w_pad=3)
    svg_path = args.results / "comparison.svg"
    fig.savefig(svg_path)
    # 统一为 LF，并去掉绘图库生成的行尾空格，便于版本管理。
    svg_text = "\n".join(line.rstrip() for line in svg_path.read_text(encoding="utf-8").splitlines()) + "\n"
    with svg_path.open("w", encoding="utf-8", newline="\n") as svg_file:
        svg_file.write(svg_text)
    fig.savefig(args.results / "comparison.png", dpi=160)
    print(svg_path)


if __name__ == "__main__":
    main()
