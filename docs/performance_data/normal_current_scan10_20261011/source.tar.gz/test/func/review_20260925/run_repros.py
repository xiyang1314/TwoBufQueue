"""Run review reproductions; nonzero case exits remain failures, never expected passes."""
import argparse
import json
import subprocess
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--exe', required=True)
parser.add_argument('--out', required=True, type=Path)
args = parser.parse_args()
results = {}
for case in ('address_control','address','restart_control','replace','pending_replace','interval','stop_deadline'):
    result = subprocess.run([args.exe,case],text=True,encoding='utf-8',errors='replace',
                            capture_output=True,timeout=15)
    results[case] = dict(exit_code=result.returncode,stdout=result.stdout,stderr=result.stderr)
args.out.write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for case, result in results.items():
    print(case, 'exit_code='+str(result['exit_code']))
raise SystemExit(1 if any(result['exit_code'] for result in results.values()) else 0)
