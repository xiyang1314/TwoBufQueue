#include "../../writer_fixture.hpp"
#include "../../warm_pool_test_support.hpp"
#include "batch_read_queue/src/read/queue_reader/queue_reader.hpp"
#include "batch_read_queue/src/read/read_layer1/read_service.hpp"
#include "batch_read_queue/src/read/read_layer1/read_worker.hpp"
#include "batch_read_queue/src/write/writer.hpp"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <memory>
#include <string>
#include <stdexcept>
#include <vector>
namespace batch_read_queue {
struct ReadTestAccess {
    static void refresh(CurrentRangeReader& reader, CurrentRangeReader::SteadyClock::time_point now) {
        reader.refresh_current_state({}, now);
    }
};
}
using namespace batch_read_queue;
struct Sink {
  bool reject = false;
  unsigned calls = 0;
  std::vector<std::uint32_t> values;
  static bool call(void *p, DataBatch &batch) noexcept {
    auto &self = *static_cast<Sink *>(p);
    ++self.calls;
    if (self.reject)
      return false;
    for (auto &frame : batch.frames) {
      for (std::size_t at = 0; at < frame.size();) {
        const auto *d = frame.data() + at;
        auto n = std::to_integer<unsigned>(d[0]) +
                 (std::to_integer<unsigned>(d[1]) << 8);
        if ((n != 4 && n != 8) || at + 2 + n > frame.size())
          std::_Exit(70);
        for (unsigned offset = 0; offset < n; offset += 4) {
          std::uint32_t value;
          std::memcpy(&value, d + 2 + offset, 4);
          self.values.push_back(value);
        }
        at += 2 + n;
      }
    }
    return true;
  }
  static bool read(void *p, const ReadBatch &batch) noexcept {
    auto &self = *static_cast<Sink *>(p);
    ++self.calls;
    if (self.reject)
      return false;
    for (auto* block : batch.blocks) {
      auto frame = block->readable();
      for (std::size_t at = 0; at < frame.size();) {
        const auto *d = frame.data() + at;
        auto n = std::to_integer<unsigned>(d[0]) +
                 (std::to_integer<unsigned>(d[1]) << 8);
        if ((n != 4 && n != 8) || at + 2 + n > frame.size())
          std::_Exit(70);
        for (unsigned offset = 0; offset < n; offset += 4) {
          std::uint32_t value;
          std::memcpy(&value, d + 2 + offset, 4);
          self.values.push_back(value);
        }
        at += 2 + n;
      }
    }
    return true;
  }
  ReadCallback read_callback() { return {read, this}; }
  DataCallback callback() { return {call, this}; }
};
struct Word {
  std::uint32_t value;
  const Word *operator&() const noexcept;
};
const Word decoy{0x55667788};
const Word *Word::operator&() const noexcept { return std::addressof(decoy); }
static_assert(std::is_trivially_copyable_v<Word>);

bool address_case(bool raw, bool multi = false) {
  WriterFixture pool(64, 1, 1);
  Writer<> writer(&pool.queue, 0, pool.backpressure);
  Sink sink;
  ReadWorker reader({}, sink.read_callback(), sink.read_callback());
  if (!reader.add_writer(&writer))
    std::_Exit(71);
  const Word input{0x11223344};
  const Word second{0x99aabbcc};
  const bool accepted =
      raw ? writer.write_mem(std::addressof(input), sizeof(input))
          : multi ? writer.write(input, second) : writer.write(input);
  writer.finish();
  if (!reader.start())
    std::_Exit(72);
  reader.stop();
  std::cout << "accepted=" << accepted << " count=" << sink.values.size()
            << " expected=" << std::hex << input.value
            << " actual=" << (sink.values.empty() ? 0 : sink.values[0])
            << " read_error=" << unsigned(reader.error_code()) << '\n';
  return accepted && sink.values.size() == (multi ? 2u : 1u) &&
      sink.values[0] == input.value && (!multi || sink.values[1] == second.value);
}
bool replace_case(bool reuse) {
  WriterFixture pool(64, 1, 1);
  Writer<> writer(&pool.queue, 0, pool.backpressure);
  Sink sink;
  auto reader = std::make_unique<ReadWorker>(ReadConfig{}, sink.read_callback(),
                                             sink.read_callback());
  if (!reader->add_writer(&writer) || !reader->start())
    std::_Exit(72);
  reader->stop(); // Empty producer is quiescent. Its initial handoff has been
                  // consumed.
  if (!reuse) {
    reader.reset();
    reader = std::make_unique<ReadWorker>(ReadConfig{}, sink.read_callback(),
                                          sink.read_callback());
    if (!reader->add_writer(&writer))
      std::_Exit(71);
  }
  bool accepted = writer.write(std::uint32_t{42});
  writer.flush();
  // Follow stop's documented producer-quiescence + flush requirement.
  if (!reader->start())
    std::_Exit(72);
  reader->stop();
  std::cout << "accepted=" << accepted << " count=" << sink.values.size()
            << " read_error=" << unsigned(reader->error_code())
            << " pending_entries=" << pool.handoff_queue().pending_count() << " unread_bytes="
            << writer.source_block()->read_snapshot().published_size -
                   writer.source_block()->read_size()
            << '\n';
  return accepted && sink.values.size() == 1 && sink.values[0] == 42;
}
bool pending_case() {
  WriterFixture pool(64, 1, 1);
  Writer<> writer(&pool.queue, 0, pool.backpressure);
  Sink sink;
  sink.reject = true;
  AutoResetEvent event;
  const std::atomic<bool> cancel{false};
  if (!writer.write(std::uint32_t{42}))
    std::_Exit(71);
  writer.finish();
  {
    ReadService reader({}, event, sink.read_callback(), sink.read_callback());
    if (!reader.add_writer(&writer, false))
      std::_Exit(71);
    (void)reader.drain_finished_ranges(cancel);
  }
  std::cout << "first_callback_rejected=" << sink.calls
            << " pending_entries=" << pool.handoff_queue().pending_count() << std::endl;
  TestDiagnostics<TestBlockPool<ReaderBlock<>>>::set_error_handler(
      [](const auto &) noexcept { std::_Exit(73); });
  sink.reject = false;
  ReadService reader({}, event, sink.read_callback(), sink.read_callback());
  if (!reader.add_writer(&writer, false))
    std::_Exit(71);
  (void)reader.drain_finished_ranges(cancel);
  return sink.values.size() == 1 && sink.values[0] == 42;
}
bool interval_case() {
  WriterFixture pool(64, 1, 1);
  Writer<> writer(&pool.queue, 0, pool.backpressure);
  Sink sink;
  ReadConfig config;
  config.idle_rescan_interval = std::chrono::nanoseconds::max();
  config.idle_rescan_max_interval = std::chrono::nanoseconds::max();
  ReadWorker reader(config, sink.read_callback(), sink.read_callback());
  std::cout << "registering positive max scan interval" << std::endl;
  const bool registered = reader.add_writer(&writer);
  std::cout << "registered=" << registered << std::endl;
  return true; // Run under UBSan: rejection or saturating arithmetic are both
               // valid fixes.
}
bool interval_boundaries_case() {
  using Clock = CurrentRangeReader::SteadyClock;
  using Duration = Clock::duration;
  using Point = Clock::time_point;
  WriterFixture pool(64, 1, 1);
  ReadConfig config;
  config.idle_rescan_interval = Duration::max();
  config.idle_rescan_max_interval = Duration::max();
  CurrentRangeReader reader(0, pool.handoff_queue(), config);
  const Point now{Duration{100}};
  ReadTestAccess::refresh(reader, now);
  if (reader.next_scan_deadline() != Point::max()) return false;
  std::vector<SpscWriteBlock*> batch;
  (void)reader.scan_due_current_ranges(true, now, batch);
  if (reader.next_scan_deadline() != Point::max()) return false;
  // Negative clock origins must not overflow a max-now subtraction either.
  ReadTestAccess::refresh(reader, Point::min());
  if (reader.next_scan_deadline() != Point{Duration{-1}}) return false;
  config.idle_rescan_interval = Duration{10};
  config.idle_rescan_max_interval = Duration{40};
  CurrentRangeReader normal(1, pool.handoff_queue(), config);
  ReadTestAccess::refresh(normal, now);
  if (normal.next_scan_deadline() != Point{Duration{110}}) return false;
  for (auto expected : {120, 140, 140}) {
    (void)normal.scan_due_current_ranges(true, now, batch);
    if (normal.next_scan_deadline() != Point{Duration{expected}}) return false;
  }
  ReadTestAccess::refresh(normal, Point::max() - Duration{5});
  if (normal.next_scan_deadline() != Point::max()) return false;
  // Invalid intervals remain rejected by start, but registration is safe.
  for (auto invalid : {Duration::min(), Duration{-1}, Duration{0}}) {
    config.idle_rescan_interval = invalid;
    config.idle_rescan_max_interval = Duration::max();
    CurrentRangeReader disabled(2, pool.handoff_queue(), config);
    ReadTestAccess::refresh(disabled, now);
    (void)disabled.scan_due_current_ranges(true, now, batch);
    if (disabled.next_scan_deadline() != now) return false;
    WriterFixture writer_pool(64, 1, 1);
    Writer<> writer(&writer_pool.queue, 0, writer_pool.backpressure);
    Sink sink;
    ReadWorker worker(config, sink.read_callback(), sink.read_callback());
    if (!worker.add_writer(&writer) || worker.start()) return false;
  }
  return true;
}
bool stop_deadline_case(int timeout = 10, bool drain = true) {
  BigMemoryStoreConfig config;
  config.block_size = 64;
  config.initial_block_count = 1;
  config.max_block_count = 1;
  BigMemoryStore store(config);
  const std::byte bytes[]{std::byte{4}, std::byte{0}, std::byte{42},
                          std::byte{0}, std::byte{0}, std::byte{0}};
  const DataView view{0, bytes, sizeof(bytes)};
  if (store.save(std::span{&view, 1}, 0).processed != 1)
    std::_Exit(74);
  store.finish();
  struct Reject {
    std::atomic<bool> called{false};
    bool accept = false;
    Sink sink;
    static bool callback(void *p, DataBatch &batch) noexcept {
      auto &self = *static_cast<Reject *>(p);
      self.called = true;
      return self.accept && Sink::call(&self.sink, batch);
    }
  } reject;
  QueueReader reader(store, {Reject::callback, &reject},
                     std::chrono::milliseconds{2000});
  if (!reader.start())
    std::_Exit(72);
  const auto wait_until =
      std::chrono::steady_clock::now() + std::chrono::seconds{5};
  while (!reject.called.load()) {
    if (std::chrono::steady_clock::now() >= wait_until)
      std::_Exit(75);
    std::this_thread::yield();
  }
  const auto before = std::chrono::steady_clock::now();
  const auto drained = reader.stop(drain, std::chrono::milliseconds{timeout});
  const auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
                           std::chrono::steady_clock::now() - before)
                           .count();
  reject.accept =
      true; // Worker has joined; no concurrent access to this non-atomic field.
  if (!reader.poll())
    std::_Exit(76);
  std::cout << "requested_timeout_ms=" << timeout << " retry_ms=2000 actual_ms=" << elapsed
            << " drained=" << drained << '\n';
  return !drained && elapsed < 500 && reject.sink.values == std::vector<std::uint32_t>{42} && !reader.poll();
}
// Retry must be convertible before entering AutoResetEvent::wait_for.
// Cover both sides of that boundary and cancellation of a valid long wait.
bool retry_boundaries_case() {
  using Milliseconds = std::chrono::milliseconds;
  const auto maximum = std::chrono::duration_cast<Milliseconds>(
      AutoResetEvent::Clock::duration::max());
  BigMemoryStore store;
  const DataCallback callback{
      [](void *, DataBatch &) noexcept { return true; }, nullptr};
  const auto rejected = [&](Milliseconds retry) {
    try {
      QueueReader reader(store, callback, retry);
    } catch (const std::invalid_argument &) {
      return true;
    }
    return false;
  };
  for (const auto retry : {Milliseconds::min(), Milliseconds{-1}, Milliseconds{0}})
    if (!rejected(retry)) return false;
  if (maximum < Milliseconds::max()) {
    if (!rejected(maximum + Milliseconds{1}) ||
        !rejected(Milliseconds::max())) return false;
  }
  for (const auto retry : {Milliseconds{1}, Milliseconds{1000}, maximum}) {
    QueueReader reader(store, callback, retry);
    if (!reader.start()) return false;
    std::this_thread::sleep_for(Milliseconds{20});
    const auto before = AutoResetEvent::Clock::now();
    if (!reader.stop(false)) return false;
    if (AutoResetEvent::Clock::now() - before > std::chrono::seconds{2})
      return false;
  }
  return true;
}
int main(int argc, char **argv) {
  if (argc != 2)
    return 2;
  const std::string name = argv[1];
  bool ok = false;
  if (name == "retry_boundaries")
    ok = retry_boundaries_case();
  else if (name == "address")
    ok = address_case(false);
  else if (name == "address_multi")
    ok = address_case(false, true);
  else if (name == "address_control")
    ok = address_case(true);
  else if (name == "replace")
    ok = replace_case(false);
  else if (name == "restart_control")
    ok = replace_case(true);
  else if (name == "pending_replace")
    ok = pending_case();
  else if (name == "interval_boundaries")
    ok = interval_boundaries_case();
  else if (name == "interval")
    ok = interval_case();
  else if (name == "stop_zero")
    ok = stop_deadline_case(0);
  else if (name == "stop_negative")
    ok = stop_deadline_case(-1);
  else if (name == "stop_fast")
    ok = stop_deadline_case(10, false);
  else if (name == "stop_deadline")
    ok = stop_deadline_case();
  else
    return 2;
  std::cout << (ok ? "PASS" : "FAIL") << " " << name << '\n';
  return ok ? 0 : 1;
}
