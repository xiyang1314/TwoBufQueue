"""Finite SC interleaving model, NOT a C++ weak-memory model checker.

One serialized pop role, one serialized push role, persistent nodes.
Every pop must clear its link then hand ownership to the push role.
Each load/link access/CAS/ownership handoff is a separate transition.
Two-bit generation is diagnostic state, not part of the algorithm.
"""
from collections import deque

def run(n):
    # head, links, owners(0=stack,1=pop,2=returned,3=push), generations,
    # pop(pc,observed,next,generation), push(pc,node,observed)
    initial = (0, tuple(range(1,n)) + (-1,), (0,)*n, (0,)*n,
               (0,-1,-1,-1), (0,-1,-1))
    seen = {initial}
    queue = deque([initial])
    transitions = 0
    def checked(s):
        h, links, owners, _, _, _ = s
        chain = set()
        while h != -1:
            assert h not in chain, ('cycle', s)
            assert owners[h] == 0, ('resurrected node', s)
            chain.add(h)
            h = links[h]
        assert chain == {i for i,x in enumerate(owners) if x == 0}, ('lost node',s)
    while queue:
        state = queue.popleft()
        head, ln, ow, gn, pop, push = state
        for role in (0,1):
            choices = [None]
            if role == 1 and push[0] == 0:
                choices = [i for i,x in enumerate(ow) if x == 2]
            for choice in choices:
                h=head; links=list(ln); owners=list(ow); gen=list(gn)
                p=list(pop); q=list(push)
                if role == 0:
                    pc, a, b, oldgen = p
                    if pc == 0:
                        if h == -1: continue
                        p = [1,h,-1,gen[h]]
                    elif pc == 1:
                        assert owners[a] == 0
                        p = [2,a,links[a],oldgen]
                    elif pc == 2:
                        if h == a:
                            assert gen[a] == oldgen, ('ABA generation',state)
                            assert links[a] == b, ('stale next',state)
                            h=b; owners[a]=1; p[0]=3
                        else:
                            p = [1,h,-1,gen[h]] if h != -1 else [0,-1,-1,-1]
                    elif pc == 3:
                        links[a]=-1; p[0]=4
                    else:
                        owners[a]=2; p=[0,-1,-1,-1]
                else:
                    pc, a, observed=q
                    if pc == 0:
                        owners[choice]=3; q=[1,choice,-1]
                    elif pc == 1:
                        q=[2,a,h]
                    elif pc == 2:
                        links[a]=observed; q[0]=3
                    else:
                        if h == observed:
                            h=a; owners[a]=0; gen[a]=(gen[a]+1)%4; q=[0,-1,-1]
                        else:
                            q=[2,a,h]
                new=(h,tuple(links),tuple(owners),tuple(gen),tuple(p),tuple(q))
                checked(new); transitions+=1
                if new not in seen:
                    seen.add(new); queue.append(new)
    print(f'PASS nodes={n} reachable_states={len(seen)} transitions={transitions}')

for count in (1,2,3):
    run(count)
