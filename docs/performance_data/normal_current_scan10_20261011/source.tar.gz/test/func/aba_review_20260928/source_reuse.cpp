#include "batch_read_queue/src/read/read_ctrl/read_service.hpp"
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <optional>
#include <vector>
using namespace batch_read_queue;
void require(bool condition) { if (!condition) std::exit(1); }
struct Sink {
    bool retain = false;
    std::optional<DataFrame> held;
    std::vector<std::uint32_t> values;
    static bool callback(void* context, DataBatch& batch) noexcept {
        auto& self=*static_cast<Sink*>(context);
        for (auto& frame:batch.frames) {
            require(frame.size()==6);
            require(frame.data()[0]==std::byte{4} && frame.data()[1]==std::byte{0});
            std::uint32_t value;
            std::memcpy(&value,frame.data()+2,4); self.values.push_back(value);
            if (self.retain) { require(!self.held); self.held.emplace(std::move(frame)); }
        }
        return true;
    }
};
void check(bool retain) {
    WriteBufMgr pool(6,1,1);
    WriteMem<> writer(&pool.queue, 0, pool.backpressure);
    AutoResetEvent event;
    Sink sink; sink.retain=retain;
    ReadService reader({},event,{Sink::callback,&sink},{Sink::callback,&sink});
    std::atomic<bool> cancel{false};
    require(reader.add_writer(&writer, false));
    (void)reader.drain_finished_ranges(cancel);
    require(writer.write(std::uint32_t{111}));
    auto* const old=writer.mem_range();
    const auto old_generation=old->sequence_;
    require(!writer.write(std::uint32_t{222})); // old block queued; no spare block
    (void)reader.drain_finished_ranges(cancel);
    if (retain) {
        require(sink.held.has_value());
        for (unsigned i=0;i<1000;++i) require(!writer.write(std::uint32_t{222}));
        std::uint32_t value; std::memcpy(&value,sink.held->data()+2,4); require(value==111);
        sink.held.reset(); sink.retain=false;
    }
    require(writer.write(std::uint32_t{222}));
    auto* const fresh=writer.mem_range();
    require(fresh==old && fresh->sequence_!=old_generation);
    const auto new_generation=fresh->sequence_;
    // Read through the newly acquired writer-owned pointer, never dereference a
    // stale old pointer concurrently with the reader or producer.
    std::uint32_t value; std::memcpy(&value,fresh->buf_+2,4); require(value==222);
    writer.finish(); (void)reader.drain_finished_ranges(cancel);
    require(sink.values==std::vector<std::uint32_t>{111,222});
    require(reader.error_code()==ReadError::none && pool.in_use_count()==0);
    std::cout << "PASS " << (retain?"retained frame pins single source block":"raw pointer address repeats across generations")
              << " generation=" << old_generation << "->" << new_generation << '\n';
}
int main() { check(false); check(true); }
