#include "instrumented_stack.hpp"
#include <chrono>
#include <cstdlib>
#include <iostream>
#include <thread>
using namespace batch_read_queue;
struct Node { Node* next = nullptr; };
using Stack = HookedStack<Node, &Node::next>;
std::atomic<bool> reached{false}, resume{false};
void require(bool condition) {
    if (!condition) { std::cerr << "FAIL\n"; std::exit(1); }
}
void wait(std::atomic<bool>& value) {
    const auto limit=std::chrono::steady_clock::now()+std::chrono::seconds{5};
    while (!value.load(std::memory_order_acquire)) {
        require(std::chrono::steady_clock::now()<limit);
        std::this_thread::yield();
    }
}
void pause_cas() { reached.store(true,std::memory_order_release); wait(resume); }
void reset() { reached=false; resume=false; }
void paused_pop() {
    reset(); Stack s; Node a,b,c; s.push(&b); s.push(&a); Node* got=nullptr;
    std::thread t([&]{audit_before_pop=pause_cas; got=s.pop();});
    wait(reached); s.push(&c); resume.store(true,std::memory_order_release); t.join();
    require(got==&c && s.pop()==&a && s.pop()==&b && s.pop()==nullptr);
    std::cout << "PASS paused pop retries after concurrent push\n";
}
void paused_push() {
    reset(); Stack s; Node a,b,c; s.push(&b); s.push(&a);
    std::thread t([&]{audit_before_push=pause_cas; s.push(&c);});
    wait(reached); require(s.pop()==&a && s.pop()==&b);
    resume.store(true,std::memory_order_release); t.join();
    require(s.pop()==&c && s.pop()==nullptr);
    std::cout << "PASS paused push repairs stale link after concurrent pops\n";
}
void unsupported_two_poppers() {
    reset(); Stack s; Node a,b,c; s.push(&c); s.push(&b); s.push(&a); Node* got=nullptr;
    std::thread t([&]{audit_before_pop=pause_cas; got=s.pop();});
    wait(reached);
    // Intentionally violate the one-pop-role contract: negative control only.
    require(s.pop()==&a && s.pop()==&b); s.push(&a);
    resume.store(true,std::memory_order_release); t.join();
    // Stale cached next resurrects b, which is still held outside the stack.
    require(got==&a && s.pop()==&b && s.pop()==nullptr);
    std::cout << "PASS negative control detects ABA with two overlapping poppers (unsupported)\n";
}
int main() { paused_pop(); paused_push(); unsupported_two_poppers(); }
