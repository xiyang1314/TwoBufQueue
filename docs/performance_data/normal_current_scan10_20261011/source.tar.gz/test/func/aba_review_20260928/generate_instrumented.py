"""Generate a test-only stack copy; never modify production source."""
from pathlib import Path
import hashlib
import sys
root=Path(__file__).resolve().parent
component=Path(sys.argv[1]) if len(sys.argv)>1 else root.parents[2]
output=Path(sys.argv[2]) if len(sys.argv)>2 else root
output.mkdir(parents=True,exist_ok=True)
source=component/'src/utils/spsc_intrusive_stack.hpp'
s=source.read_text(encoding='utf-8')
s=s.replace('class alignas(64) SpscIntrusiveStack', 'class alignas(64) HookedStack')
s=s.replace('SpscIntrusiveStack(', 'HookedStack(').replace('const SpscIntrusiveStack&','const HookedStack&').replace('SpscIntrusiveStack& operator=', 'HookedStack& operator=')
s=s.replace('namespace batch_read_queue {', '''namespace batch_read_queue {
inline thread_local void (*audit_before_push)() = nullptr;
inline thread_local void (*audit_before_pop)() = nullptr;
inline void audit_hook(void (*&hook)()) {
    if (hook) { auto once = hook; hook = nullptr; once(); }
}
''',1)
old='node->*next_member = observed;'
assert s.count(old)==1
s=s.replace(old,old+'\n            audit_hook(audit_before_push);')
old='Node* const next = observed->*next_member;'
assert s.count(old)==1
s=s.replace(old,old+'\n            audit_hook(audit_before_pop);')
(output/'instrumented_stack.hpp').write_text(s,encoding='utf-8')
(output/'instrumentation-sha256.txt').write_text('production='+hashlib.sha256(source.read_bytes()).hexdigest()+'\ncopy='+hashlib.sha256(s.encode()).hexdigest()+'\n')
