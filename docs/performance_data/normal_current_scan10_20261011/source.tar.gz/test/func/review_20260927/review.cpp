#include "batch_read_queue/src/read/read_ctrl/read_service.hpp"
#include "batch_read_queue/src/read/queue_reader/queue_reader.hpp"
#include "batch_read_queue/src/read/to_big_mem/save_memory_adapter.hpp"
#include <algorithm>
#include <array>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <memory>
#include <random>
#include <string>
using namespace batch_read_queue;
using Bytes=std::vector<std::byte>;
[[noreturn]] void fail(const char* reason){ std::cerr << reason << std::endl; std::exit(1); }
struct Sink {
 std::array<std::vector<Bytes>,3> expected;
 std::array<std::size_t,3> position{};
 struct Held { DataFrame frame; Bytes snapshot; };
 std::vector<Held> held;
 std::mt19937 random{1123};
 bool reject=true;
 unsigned rejected=0;
 static bool callback(void* context,DataBatch& batch) noexcept {
  auto& s=*static_cast<Sink*>(context);
  if(s.reject && s.random()%4==0){++s.rejected;return false;}
  std::size_t bytes=0;
  for(auto& f:batch.frames){
   if(f.thread_id<0||f.thread_id>=3)fail("wrong thread id");
   auto id=static_cast<std::size_t>(f.thread_id);bytes+=f.size();
   for(std::size_t at=0;at<f.size();){
    if(f.size()-at<2)fail("partial prefix");
    auto n=std::to_integer<unsigned>(f.data()[at])+(std::to_integer<unsigned>(f.data()[at+1])<<8);at+=2;
    if(n>f.size()-at)fail("partial payload");
    if(s.position[id]>=s.expected[id].size())fail("unexpected duplicate");
    const auto& wanted=s.expected[id][s.position[id]++];
    if(wanted.size()!=n||!std::equal(wanted.begin(),wanted.end(),f.data()+at))fail("wrong payload/order");
    at+=n;
   }
   Bytes snapshot(f.data(),f.data()+f.size());
   s.held.push_back({std::move(f),std::move(snapshot)});
  }
  if(bytes!=batch.data_size)fail("wrong batch byte count");
  return true;
 }
 void release_one(){
  if(held.empty())return;
  auto i=random()%held.size(); auto& h=held[i];
  if(h.frame.size()!=h.snapshot.size()||!std::equal(h.snapshot.begin(),h.snapshot.end(),h.frame.data()))fail("held bytes overwritten");
  held.erase(held.begin()+i);
 }
};
template<unsigned Publish> std::size_t exercise(bool buffered,std::size_t block,unsigned pool_count,unsigned slots,unsigned seed){
 std::mt19937 rng(seed);Sink sink;
 std::array<std::unique_ptr<WriteBufMgr>,3> pools;
 std::array<std::unique_ptr<WriteMem<Publish>>,3> writers;
 for(int i=0;i<3;++i){pools[i]=std::make_unique<WriteBufMgr>(block,pool_count,pool_count);writers[i]=std::make_unique<WriteMem<Publish>>(pools[i].get(),i);}
 BigMemoryStoreConfig cfg;cfg.block_size=block;cfg.initial_block_count=1;cfg.max_block_count=2;cfg.batch_queue_capacity=1;cfg.max_batch_bytes=block;cfg.max_slices_per_block=slots;
 BigMemoryStore store(cfg);SaveMemoryAdapter adapter(store);
 AutoResetEvent event; std::atomic<bool> cancel{false};
 DataCallback handler{Sink::callback,&sink};
 ReadService reader({},event,buffered?adapter.completed_callback():handler,buffered?adapter.current_callback():handler);
 QueueReader consumer(store,handler);
 for(int i=0;i<3;++i)if(!reader.add_writer(writers[i].get(), false))fail("register");
 for(unsigned step=0;step<5000;++step){
  switch(rng()%7){
  case 0:case 1:case 2:{auto id=rng()%3;auto size=rng()%std::min<std::size_t>(block-1,201);Bytes data(size);for(std::size_t j=0;j<size;++j)data[j]=std::byte((seed+step*19+j*7+id*13)&255);if(writers[id]->write_mem(data.data(),data.size()))sink.expected[id].push_back(data);std::fill(data.begin(),data.end(),std::byte{0xdd});if(rng()%3==0)writers[id]->flush();break;}
  case 3:(void)reader.drain_finished_ranges(cancel);break;
  case 4:(void)reader.scan_due_current_ranges(true,cancel);break;
  case 5:if(buffered)(void)consumer.poll();break;
  case 6:sink.release_one();break;
  }
  if(reader.error_code()!=ReadError::none||adapter.error_code()!=StoreError::none)fail("reader/store error");
 }
 for(auto& w:writers)w->finish();sink.reject=false;
 for(unsigned i=0;i<10000;++i){
  (void)reader.drain_finished_ranges(cancel);bool done=reader.scan_due_current_ranges(true,cancel);
  if(buffered)(void)consumer.poll();sink.release_one();
  bool all=true;for(int j=0;j<3;++j)all&=sink.position[j]==sink.expected[j].size();
  if(all&&done&&!reader.has_pending_finished())break;
  if(i==9999)fail("accepted messages missing after drain");
 }
 store.finish();while(buffered&&consumer.poll()){}while(!sink.held.empty())sink.release_one();
 std::size_t count=0;for(int j=0;j<3;++j){if(sink.position[j]!=sink.expected[j].size())fail("count");count+=sink.position[j];}
 return count;
}
int main(int argc,char** argv){
 if(argc>1&&std::string(argv[1])=="retry_overflow"){
  BigMemoryStore store;QueueReader reader(store,{[](void*,DataBatch&)noexcept{return true;},nullptr},std::chrono::milliseconds::max());
  if(!reader.start())return 2;std::this_thread::sleep_for(std::chrono::milliseconds{20});(void)reader.stop(false);return 0;
 }
 unsigned configs=0;std::size_t accepted=0;
 for(auto block:{2u,3u,16u,64u,127u,65537u})for(auto count:{1u,2u})for(auto slots:{1u,64u,65u})for(bool buffered:{false,true}){
  accepted+=exercise<1>(buffered,block,count,slots,++configs);
  accepted+=exercise<32>(buffered,block,count,slots,++configs);
 }
 std::cout<<"PASS configs="<<configs<<" actions="<<configs*5000<<" accepted_verified="<<accepted<<std::endl;
}
